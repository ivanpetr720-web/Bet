import { pgTable, text, serial, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const betsTable = pgTable("bets", {
  id: serial("id").primaryKey(),
  matchId: text("match_id"),
  matchTitle: text("match_title").notNull(),
  league: text("league"),
  leagueFlag: text("league_flag"),
  matchDate: text("match_date"),
  betLabel: text("bet_label").notNull(),
  odds: real("odds").notNull(),
  stake: real("stake").notNull(),
  outcome: text("outcome").notNull().default("pending"),
  profit: real("profit").notNull().default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertBetSchema = createInsertSchema(betsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBet = z.infer<typeof insertBetSchema>;
export type Bet = typeof betsTable.$inferSelect;
