import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const apiKeysTable = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  provider: text("provider").notNull(),
  label: text("label").notNull(),
  key: text("key").notNull(),
  status: text("status").notNull().default("untested"),
  isActive: boolean("is_active").notNull().default(true),
  lastTested: timestamp("last_tested", { withTimezone: true }),
  lastError: text("last_error"),
  requestsUsed: integer("requests_used"),
  requestsLimit: integer("requests_limit"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertApiKeySchema = createInsertSchema(apiKeysTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertApiKey = z.infer<typeof insertApiKeySchema>;
export type ApiKeyRecord = typeof apiKeysTable.$inferSelect;
