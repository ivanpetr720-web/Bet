import { Router } from "express";
import { db } from "@workspace/db";
import { apiKeysTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  getTeamMatches,
  normalizeFDStatus,
  type FDMatch,
} from "../services/footballData.js";

const router = Router();

async function getKey(provider: string): Promise<string | null> {
  const keys = await db
    .select()
    .from(apiKeysTable)
    .where(and(eq(apiKeysTable.provider, provider), eq(apiKeysTable.isActive, true)))
    .limit(1);
  return keys[0]?.key ?? null;
}

function toFormResult(m: FDMatch, teamId: number): "W" | "D" | "L" {
  const isHome = m.homeTeam.id === teamId;
  const h = m.score?.fullTime?.home ?? 0;
  const a = m.score?.fullTime?.away ?? 0;
  if (isHome) return h > a ? "W" : h === a ? "D" : "L";
  return a > h ? "W" : a === h ? "D" : "L";
}

router.get("/analytics/team-form", async (req, res) => {
  try {
    const teamId = req.query["teamId"] as string | undefined;
    const limit = Math.min(20, Number(req.query["limit"]) || 10);

    if (!teamId) {
      res.status(400).json({ error: "teamId is required" });
      return;
    }

    const fdKey = await getKey("football-data");
    if (!fdKey) {
      res.status(503).json({ error: "No Football-Data.org API key configured. Add one in API Settings." });
      return;
    }

    const matches = await getTeamMatches(fdKey, Number(teamId), limit);
    const teamNumId = Number(teamId);

    let teamName = "";
    let crest = "";
    for (const m of matches) {
      if (m.homeTeam.id === teamNumId) { teamName = m.homeTeam.name; crest = m.homeTeam.crest; break; }
      if (m.awayTeam.id === teamNumId) { teamName = m.awayTeam.name; crest = m.awayTeam.crest; break; }
    }

    const recentMatches = matches.map((m) => {
      const isHome = m.homeTeam.id === teamNumId;
      const result = toFormResult(m, teamNumId);
      const h = m.score?.fullTime?.home ?? null;
      const a = m.score?.fullTime?.away ?? null;
      return {
        date: new Date(m.utcDate).toLocaleDateString("en-GB"),
        opponent: isHome ? m.awayTeam.name : m.homeTeam.name,
        opponentCrest: isHome ? m.awayTeam.crest : m.homeTeam.crest,
        result,
        score: h !== null && a !== null ? `${h}-${a}` : "?-?",
        isHome,
        league: m.competition.name,
      };
    });

    const finished = matches.filter((m) => normalizeFDStatus(m.status) === "finished");
    const won = finished.filter((m) => toFormResult(m, teamNumId) === "W").length;
    const drawn = finished.filter((m) => toFormResult(m, teamNumId) === "D").length;
    const lost = finished.length - won - drawn;
    const goalsFor = finished.reduce((s, m) => {
      const isHome = m.homeTeam.id === teamNumId;
      return s + (isHome ? (m.score?.fullTime?.home ?? 0) : (m.score?.fullTime?.away ?? 0));
    }, 0);
    const goalsAgainst = finished.reduce((s, m) => {
      const isHome = m.homeTeam.id === teamNumId;
      return s + (isHome ? (m.score?.fullTime?.away ?? 0) : (m.score?.fullTime?.home ?? 0));
    }, 0);

    res.json({
      teamId,
      teamName,
      crest,
      recentMatches,
      stats: {
        played: finished.length,
        won,
        drawn,
        lost,
        goalsFor,
        goalsAgainst,
        form: recentMatches.slice(0, 5).map((m) => m.result),
        avgGoalsScored: finished.length > 0 ? goalsFor / finished.length : 0,
        avgGoalsConceded: finished.length > 0 ? goalsAgainst / finished.length : 0,
        cleanSheets: finished.filter((m) => {
          const isHome = m.homeTeam.id === teamNumId;
          return isHome ? (m.score?.fullTime?.away ?? 1) === 0 : (m.score?.fullTime?.home ?? 1) === 0;
        }).length,
        bttsRate: finished.length > 0
          ? finished.filter((m) => (m.score?.fullTime?.home ?? 0) > 0 && (m.score?.fullTime?.away ?? 0) > 0).length / finished.length
          : 0,
        over25Rate: finished.length > 0
          ? finished.filter((m) => ((m.score?.fullTime?.home ?? 0) + (m.score?.fullTime?.away ?? 0)) > 2.5).length / finished.length
          : 0,
      },
    });
  } catch (err) {
    req.log.error({ err }, "Error in GET /analytics/team-form");
    res.status(500).json({ error: "Failed to fetch team form" });
  }
});

router.get("/analytics/overview", async (req, res) => {
  res.json({
    topScoringTeams: [],
    bestFormTeams: [],
    leagueStats: [
      { code: "PL", name: "Premier League", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", totalGoals: 0, avgGoalsPerMatch: 0, matchesPlayed: 0 },
      { code: "PD", name: "La Liga", flag: "🇪🇸", totalGoals: 0, avgGoalsPerMatch: 0, matchesPlayed: 0 },
      { code: "BL1", name: "Bundesliga", flag: "🇩🇪", totalGoals: 0, avgGoalsPerMatch: 0, matchesPlayed: 0 },
      { code: "SA", name: "Serie A", flag: "🇮🇹", totalGoals: 0, avgGoalsPerMatch: 0, matchesPlayed: 0 },
    ],
  });
});

export default router;
