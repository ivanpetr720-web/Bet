import { Router } from "express";
import { db } from "@workspace/db";
import { apiKeysTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { z } from "zod/v4";

const router = Router();

const createKeySchema = z.object({
  provider: z.enum(["football-data", "api-football", "odds-api", "openai"]),
  label: z.string().min(1),
  key: z.string().min(1),
  isActive: z.boolean().optional().default(true),
});

const updateKeySchema = z.object({
  label: z.string().optional(),
  isActive: z.boolean().optional(),
  status: z.enum(["active", "error", "inactive", "untested"]).optional(),
});

function maskKey(key: string): string {
  if (!key || key.length < 8) return "****";
  return `${key.slice(0, 4)}${"*".repeat(Math.max(0, key.length - 8))}${key.slice(-4)}`;
}

function formatKey(k: typeof apiKeysTable.$inferSelect) {
  return {
    id: String(k.id),
    provider: k.provider,
    label: k.label,
    keyMasked: maskKey(k.key),
    status: k.status as "active" | "error" | "inactive" | "untested",
    isActive: k.isActive,
    lastTested: k.lastTested?.toISOString() ?? null,
    lastError: k.lastError ?? null,
    requestsUsed: k.requestsUsed ?? null,
    requestsLimit: k.requestsLimit ?? null,
    createdAt: k.createdAt.toISOString(),
  };
}

async function testFootballDataKey(key: string): Promise<{ ok: boolean; message: string; responseTime: number }> {
  const start = Date.now();
  const res = await fetch("https://api.football-data.org/v4/competitions", {
    headers: { "X-Auth-Token": key },
    signal: AbortSignal.timeout(8000),
  });
  const elapsed = Date.now() - start;
  if (res.ok) return { ok: true, message: "Connected to Football-Data.org", responseTime: elapsed };
  const text = await res.text().catch(() => "");
  return { ok: false, message: `HTTP ${res.status}: ${text.slice(0, 100)}`, responseTime: elapsed };
}

async function testApiFootballKey(key: string): Promise<{ ok: boolean; message: string; responseTime: number }> {
  const start = Date.now();
  const res = await fetch("https://v3.football.api-sports.io/status", {
    headers: { "x-apisports-key": key },
    signal: AbortSignal.timeout(8000),
  });
  const elapsed = Date.now() - start;
  if (res.ok) return { ok: true, message: "Connected to API-Football", responseTime: elapsed };
  return { ok: false, message: `HTTP ${res.status}`, responseTime: elapsed };
}

async function testOddsApiKey(key: string): Promise<{ ok: boolean; message: string; responseTime: number }> {
  const start = Date.now();
  const res = await fetch(`https://api.the-odds-api.com/v4/sports?apiKey=${key}`, {
    signal: AbortSignal.timeout(8000),
  });
  const elapsed = Date.now() - start;
  if (res.ok) {
    const used = res.headers.get("x-requests-used");
    const remaining = res.headers.get("x-requests-remaining");
    return { ok: true, message: `Connected — Used: ${used ?? "?"}, Remaining: ${remaining ?? "?"}`, responseTime: elapsed };
  }
  return { ok: false, message: `HTTP ${res.status}`, responseTime: elapsed };
}

async function testOpenAIKey(key: string): Promise<{ ok: boolean; message: string; responseTime: number }> {
  const start = Date.now();
  const res = await fetch("https://api.openai.com/v1/models", {
    headers: { Authorization: `Bearer ${key}` },
    signal: AbortSignal.timeout(8000),
  });
  const elapsed = Date.now() - start;
  if (res.ok) return { ok: true, message: "Connected to OpenAI API", responseTime: elapsed };
  return { ok: false, message: `HTTP ${res.status} — Invalid key or insufficient permissions`, responseTime: elapsed };
}

router.get("/api-keys", async (req, res) => {
  try {
    const keys = await db.select().from(apiKeysTable).orderBy(apiKeysTable.createdAt);
    res.json(keys.map(formatKey));
  } catch (err) {
    req.log.error({ err }, "Error in GET /api-keys");
    res.status(500).json({ error: "Failed to fetch API keys" });
  }
});

router.post("/api-keys", async (req, res) => {
  try {
    const parsed = createKeySchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid input", details: parsed.error.issues });
      return;
    }
    const data = parsed.data;
    const [key] = await db
      .insert(apiKeysTable)
      .values({
        provider: data.provider,
        label: data.label,
        key: data.key,
        isActive: data.isActive,
        status: "untested",
      })
      .returning();

    res.status(201).json(formatKey(key!));
  } catch (err) {
    req.log.error({ err }, "Error in POST /api-keys");
    res.status(500).json({ error: "Failed to create API key" });
  }
});

router.patch("/api-keys/:id", async (req, res) => {
  try {
    const id = Number(req.params["id"]);
    if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }

    const parsed = updateKeySchema.safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: "Invalid input" }); return; }

    const data = parsed.data;
    const updates: Partial<typeof apiKeysTable.$inferInsert> = {};
    if (data.label !== undefined) updates.label = data.label;
    if (data.isActive !== undefined) updates.isActive = data.isActive;
    if (data.status !== undefined) updates.status = data.status;

    const [updated] = await db.update(apiKeysTable).set(updates).where(eq(apiKeysTable.id, id)).returning();
    if (!updated) { res.status(404).json({ error: "API key not found" }); return; }
    res.json(formatKey(updated));
  } catch (err) {
    req.log.error({ err }, "Error in PATCH /api-keys/:id");
    res.status(500).json({ error: "Failed to update API key" });
  }
});

router.delete("/api-keys/:id", async (req, res) => {
  try {
    const id = Number(req.params["id"]);
    if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
    await db.delete(apiKeysTable).where(eq(apiKeysTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error in DELETE /api-keys/:id");
    res.status(500).json({ error: "Failed to delete API key" });
  }
});

router.post("/api-keys/:id/test", async (req, res) => {
  try {
    const id = Number(req.params["id"]);
    if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }

    const [keyRecord] = await db.select().from(apiKeysTable).where(eq(apiKeysTable.id, id)).limit(1);
    if (!keyRecord) { res.status(404).json({ error: "API key not found" }); return; }

    let testResult: { ok: boolean; message: string; responseTime: number };

    try {
      if (keyRecord.provider === "football-data") testResult = await testFootballDataKey(keyRecord.key);
      else if (keyRecord.provider === "api-football") testResult = await testApiFootballKey(keyRecord.key);
      else if (keyRecord.provider === "odds-api") testResult = await testOddsApiKey(keyRecord.key);
      else if (keyRecord.provider === "openai") testResult = await testOpenAIKey(keyRecord.key);
      else testResult = { ok: false, message: "Unknown provider", responseTime: 0 };
    } catch (e: unknown) {
      testResult = { ok: false, message: String(e instanceof Error ? e.message : e), responseTime: 0 };
    }

    const newStatus = testResult.ok ? "active" : "error";
    await db.update(apiKeysTable).set({
      status: newStatus,
      lastTested: new Date(),
      lastError: testResult.ok ? null : testResult.message,
    }).where(eq(apiKeysTable.id, id));

    res.json({
      success: testResult.ok,
      message: testResult.message,
      provider: keyRecord.provider,
      responseTime: testResult.responseTime,
      requestsUsed: null,
      requestsLimit: null,
      details: `Tested at ${new Date().toISOString()}`,
    });
  } catch (err) {
    req.log.error({ err }, "Error in POST /api-keys/:id/test");
    res.status(500).json({ error: "Failed to test API key" });
  }
});

export default router;
