import { Router } from "express";
import { db } from "@workspace/db";
import { betsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { z } from "zod/v4";

const router = Router();

const betInputSchema = z.object({
  matchId: z.string().optional(),
  matchTitle: z.string().min(1),
  league: z.string().optional(),
  leagueFlag: z.string().optional(),
  matchDate: z.string().optional(),
  betLabel: z.string().min(1),
  odds: z.number().positive(),
  stake: z.number().positive(),
  notes: z.string().optional(),
});

const betUpdateSchema = z.object({
  outcome: z.enum(["won", "lost", "pending"]).optional(),
  profit: z.number().optional(),
  notes: z.string().optional(),
});

function formatBet(b: typeof betsTable.$inferSelect) {
  return {
    id: String(b.id),
    matchId: b.matchId ?? undefined,
    matchTitle: b.matchTitle,
    league: b.league ?? undefined,
    leagueFlag: b.leagueFlag ?? undefined,
    matchDate: b.matchDate ?? undefined,
    betLabel: b.betLabel,
    odds: b.odds,
    stake: b.stake,
    outcome: b.outcome as "won" | "lost" | "pending",
    profit: b.profit,
    notes: b.notes ?? undefined,
    createdAt: b.createdAt.toISOString(),
  };
}

router.get("/betting/history", async (req, res) => {
  try {
    const outcome = req.query["outcome"] as string | undefined;
    const limit = Math.min(100, Number(req.query["limit"]) || 50);

    let query = db.select().from(betsTable).orderBy(desc(betsTable.createdAt)).limit(limit);

    const bets = await query;
    const filtered = outcome ? bets.filter((b) => b.outcome === outcome) : bets;

    res.json(filtered.map(formatBet));
  } catch (err) {
    req.log.error({ err }, "Error in GET /betting/history");
    res.status(500).json({ error: "Failed to fetch bets" });
  }
});

router.post("/betting/history", async (req, res) => {
  try {
    const parsed = betInputSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid input", details: parsed.error.issues });
      return;
    }

    const data = parsed.data;
    const [bet] = await db
      .insert(betsTable)
      .values({
        matchId: data.matchId,
        matchTitle: data.matchTitle,
        league: data.league,
        leagueFlag: data.leagueFlag,
        matchDate: data.matchDate,
        betLabel: data.betLabel,
        odds: data.odds,
        stake: data.stake,
        outcome: "pending",
        profit: 0,
        notes: data.notes,
      })
      .returning();

    res.status(201).json(formatBet(bet!));
  } catch (err) {
    req.log.error({ err }, "Error in POST /betting/history");
    res.status(500).json({ error: "Failed to create bet" });
  }
});

router.patch("/betting/history/:id", async (req, res) => {
  try {
    const id = Number(req.params["id"]);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid ID" });
      return;
    }

    const parsed = betUpdateSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid input" });
      return;
    }

    const data = parsed.data;
    const updates: Partial<typeof betsTable.$inferInsert> = {};
    if (data.outcome !== undefined) updates.outcome = data.outcome;
    if (data.profit !== undefined) updates.profit = data.profit;
    if (data.notes !== undefined) updates.notes = data.notes;

    if (data.outcome === "won" && data.profit === undefined) {
      const existing = await db.select().from(betsTable).where(eq(betsTable.id, id)).limit(1);
      if (existing[0]) {
        updates.profit = (existing[0].odds - 1) * existing[0].stake;
      }
    }
    if (data.outcome === "lost" && data.profit === undefined) {
      const existing = await db.select().from(betsTable).where(eq(betsTable.id, id)).limit(1);
      if (existing[0]) {
        updates.profit = -existing[0].stake;
      }
    }

    const [updated] = await db
      .update(betsTable)
      .set(updates)
      .where(eq(betsTable.id, id))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Bet not found" });
      return;
    }

    res.json(formatBet(updated));
  } catch (err) {
    req.log.error({ err }, "Error in PATCH /betting/history/:id");
    res.status(500).json({ error: "Failed to update bet" });
  }
});

router.delete("/betting/history/:id", async (req, res) => {
  try {
    const id = Number(req.params["id"]);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid ID" });
      return;
    }
    await db.delete(betsTable).where(eq(betsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error in DELETE /betting/history/:id");
    res.status(500).json({ error: "Failed to delete bet" });
  }
});

router.get("/betting/stats", async (req, res) => {
  try {
    const allBets = await db.select().from(betsTable).orderBy(desc(betsTable.createdAt));
    const settled = allBets.filter((b) => b.outcome !== "pending");
    const won = settled.filter((b) => b.outcome === "won");
    const lost = settled.filter((b) => b.outcome === "lost");

    const totalProfit = settled.reduce((s, b) => s + b.profit, 0);
    const totalStake = settled.reduce((s, b) => s + b.stake, 0);
    const winRate = settled.length > 0 ? (won.length / settled.length) * 100 : 0;
    const roi = totalStake > 0 ? (totalProfit / totalStake) * 100 : 0;
    const bestOddsWon = won.length > 0 ? Math.max(...won.map((b) => b.odds)) : 0;
    const avgOdds = settled.length > 0 ? settled.reduce((s, b) => s + b.odds, 0) / settled.length : 0;

    const leagueMap: Record<string, { bets: number; won: number; profit: number }> = {};
    for (const b of settled) {
      const l = b.league ?? "Unknown";
      if (!leagueMap[l]) leagueMap[l] = { bets: 0, won: 0, profit: 0 };
      leagueMap[l]!.bets++;
      if (b.outcome === "won") leagueMap[l]!.won++;
      leagueMap[l]!.profit += b.profit;
    }

    const leagueBreakdown = Object.entries(leagueMap).map(([league, s]) => ({
      league,
      bets: s.bets,
      winRate: s.bets > 0 ? (s.won / s.bets) * 100 : 0,
      profit: s.profit,
    }));

    const monthMap: Record<string, { profit: number; bets: number; won: number }> = {};
    for (const b of settled) {
      const key = b.createdAt.toISOString().slice(0, 7);
      if (!monthMap[key]) monthMap[key] = { profit: 0, bets: 0, won: 0 };
      monthMap[key]!.profit += b.profit;
      monthMap[key]!.bets++;
      if (b.outcome === "won") monthMap[key]!.won++;
    }

    const monthlyProfit = Object.entries(monthMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, s]) => ({
        month,
        profit: s.profit,
        bets: s.bets,
        winRate: s.bets > 0 ? (s.won / s.bets) * 100 : 0,
      }));

    const sorted = leagueBreakdown.sort((a, b) => b.winRate - a.winRate);
    const bestLeague = sorted[0]?.league ?? null;
    const worstLeague = sorted[sorted.length - 1]?.league ?? null;

    res.json({
      totalBets: settled.length,
      wonBets: won.length,
      lostBets: lost.length,
      pendingBets: allBets.filter((b) => b.outcome === "pending").length,
      winRate,
      roi,
      totalProfit,
      totalStake,
      bestOddsWon,
      avgOdds,
      bestLeague,
      worstLeague,
      monthlyProfit,
      leagueBreakdown,
    });
  } catch (err) {
    req.log.error({ err }, "Error in GET /betting/stats");
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

export default router;
