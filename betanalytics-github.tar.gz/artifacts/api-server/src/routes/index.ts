import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import matchesRouter from "./matches.js";
import bettingRouter from "./betting.js";
import apiKeysRouter from "./apiKeys.js";
import analyticsRouter from "./analytics.js";
import dashboardRouter from "./dashboard.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(matchesRouter);
router.use(bettingRouter);
router.use(apiKeysRouter);
router.use(analyticsRouter);
router.use(dashboardRouter);

export default router;
