import { Router } from "express";
import { db } from "@workspace/db";
import { apiKeysTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getUpcomingMatches, normalizeFDStatus, type FDMatch } from "../services/footballData.js";

const router = Router();

async function getKey(provider: string): Promise<{ key: string; id: number } | null> {
  const keys = await db
    .select()
    .from(apiKeysTable)
    .where(and(eq(apiKeysTable.provider, provider), eq(apiKeysTable.isActive, true)))
    .limit(1);
  const k = keys[0];
  return k ? { key: k.key, id: k.id } : null;
}

router.get("/dashboard/summary", async (req, res) => {
  try {
    const allKeys = await db.select().from(apiKeysTable);

    const dataSourceStatus = [
      { name: "Football-Data.org", provider: "football-data" },
      { name: "API-Football", provider: "api-football" },
      { name: "The Odds API", provider: "odds-api" },
      { name: "OpenAI", provider: "openai" },
    ].map(({ name, provider }) => {
      const key = allKeys.find((k) => k.provider === provider && k.isActive);
      return {
        name,
        status: key ? (key.status as "active" | "error" | "inactive" | "untested") : "inactive" as const,
        message: key ? key.lastError ?? undefined : "No API key configured",
        requestsUsed: key?.requestsUsed ?? null,
        requestsLimit: key?.requestsLimit ?? null,
      };
    });

    const fdKeyRec = await getKey("football-data");

    if (!fdKeyRec) {
      res.json({
        liveMatchCount: 0,
        todayMatchCount: 0,
        upcomingMatchCount: 0,
        highConfidencePredictions: [],
        dataSourceStatus,
        lastUpdated: new Date().toISOString(),
      });
      return;
    }

    let matches: FDMatch[] = [];
    try {
      matches = await getUpcomingMatches(fdKeyRec.key, 3);
    } catch {
      matches = [];
    }

    const liveMatchCount = matches.filter((m) => normalizeFDStatus(m.status) === "live").length;
    const todayMatchCount = matches.filter((m) => {
      const today = new Date().toISOString().split("T")[0];
      return m.utcDate.startsWith(today!);
    }).length;
    const upcomingMatchCount = matches.filter((m) => normalizeFDStatus(m.status) === "upcoming").length;

    res.json({
      liveMatchCount,
      todayMatchCount,
      upcomingMatchCount,
      highConfidencePredictions: [],
      dataSourceStatus,
      lastUpdated: new Date().toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Error in GET /dashboard/summary");
    res.status(500).json({ error: "Failed to fetch dashboard summary" });
  }
});

export default router;
