import { Router } from "express";
import { db } from "@workspace/db";
import { apiKeysTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  getTodayMatches,
  getUpcomingMatches,
  getMatchById,
  getH2H,
  getTeamMatches,
  normalizeFDStatus,
  getCompetitionFlag,
  type FDMatch,
} from "../services/footballData.js";
import { analyzeMatch } from "../services/aiAnalysis.js";
import { logger } from "../lib/logger.js";

const router = Router();

async function getKey(provider: string): Promise<string | null> {
  const keys = await db
    .select()
    .from(apiKeysTable)
    .where(and(eq(apiKeysTable.provider, provider), eq(apiKeysTable.isActive, true)))
    .limit(1);
  return keys[0]?.key ?? null;
}

function buildFormArray(formStr: string | null | undefined): Array<"W" | "D" | "L"> {
  if (!formStr) return [];
  return (formStr.split(",").slice(0, 5).map((r: string) => {
    const t = r.trim().toUpperCase();
    if (t === "W") return "W";
    if (t === "D") return "D";
    return "L";
  }) as Array<"W" | "D" | "L">);
}

function formScore(form: Array<"W" | "D" | "L">): number {
  return form.reduce((s, r) => s + (r === "W" ? 3 : r === "D" ? 1 : 0), 0);
}

function generateBasicPrediction(
  homeTeamName: string,
  awayTeamName: string,
  homeTla: string,
  awayTla: string,
  homeForm: Array<"W" | "D" | "L">,
  awayForm: Array<"W" | "D" | "L">
) {
  const hs = formScore(homeForm);
  const as_ = formScore(awayForm);
  const total = hs + as_;

  let outcome: "home" | "draw" | "away";
  let confidence: number;

  if (total === 0) {
    outcome = "draw";
    confidence = 50;
  } else {
    const homePct = hs / total;
    if (homePct > 0.58) {
      outcome = "home";
      confidence = Math.min(40 + Math.round(homePct * 38), 74);
    } else if (homePct < 0.42) {
      outcome = "away";
      confidence = Math.min(40 + Math.round((1 - homePct) * 38), 74);
    } else {
      outcome = "draw";
      confidence = 50;
    }
  }

  const outcomeLabel =
    outcome === "home" ? `Победа ${homeTeamName}`
    : outcome === "away" ? `Победа ${awayTeamName}`
    : "Ничья";
  const tipLabel =
    outcome === "home" ? `П1 (${homeTla})`
    : outcome === "away" ? `П2 (${awayTla})`
    : "Х";
  const tipOdds = outcome === "home" ? 2.1 : outcome === "away" ? 2.5 : 3.2;
  const riskLevel: "low" | "medium" | "high" =
    confidence >= 66 ? "low" : confidence >= 56 ? "medium" : "high";
  const riskScore = confidence >= 66 ? 3 : confidence >= 56 ? 5 : 7;

  const hasForm = homeForm.length > 0 || awayForm.length > 0;

  return {
    outcome,
    confidence,
    scoreline: outcome === "home" ? "2–1" : outcome === "away" ? "1–2" : "1–1",
    btts: false,
    over25: confidence >= 65,
    valueOutcome: outcomeLabel,
    riskLevel,
    riskScore,
    aiInsight: hasForm
      ? "Базовый прогноз по форме. Откройте матч для полного ИИ-анализа."
      : "Добавьте ключ OpenAI в Настройки API для ИИ-анализа.",
    reasoning: hasForm
      ? [
          `Форма ${homeTeamName}: ${homeForm.join("") || "нет данных"}`,
          `Форма ${awayTeamName}: ${awayForm.join("") || "нет данных"}`,
          "Откройте страницу матча для подробного анализа.",
        ]
      : ["Откройте страницу матча для загрузки анализа."],
    tips: [{ label: tipLabel, odds: tipOdds, value: 0, confidence }],
  };
}

function fdMatchToMatch(m: FDMatch) {
  const status = normalizeFDStatus(m.status);
  const flag = getCompetitionFlag(m.competition.code);
  const dt = new Date(m.utcDate);
  const date = `${String(dt.getUTCDate()).padStart(2, "0")}.${String(dt.getUTCMonth() + 1).padStart(2, "0")}`;
  const time = `${String(dt.getUTCHours()).padStart(2, "0")}:${String(dt.getUTCMinutes()).padStart(2, "0")}`;

  const homeForm = buildFormArray((m.homeTeam as any).form);
  const awayForm = buildFormArray((m.awayTeam as any).form);
  const prediction = generateBasicPrediction(
    m.homeTeam.shortName,
    m.awayTeam.shortName,
    m.homeTeam.tla,
    m.awayTeam.tla,
    homeForm,
    awayForm
  );

  return {
    id: String(m.id),
    fdId: m.id,
    homeTeam: {
      id: m.homeTeam.id,
      name: m.homeTeam.name,
      shortName: m.homeTeam.shortName,
      tla: m.homeTeam.tla,
      crest: m.homeTeam.crest,
      position: null,
      points: null,
      goalsFor: null,
      goalsAgainst: null,
      form: homeForm,
    },
    awayTeam: {
      id: m.awayTeam.id,
      name: m.awayTeam.name,
      shortName: m.awayTeam.shortName,
      tla: m.awayTeam.tla,
      crest: m.awayTeam.crest,
      position: null,
      points: null,
      goalsFor: null,
      goalsAgainst: null,
      form: awayForm,
    },
    status,
    date,
    time,
    utcDate: m.utcDate,
    league: m.competition.name,
    leagueFlag: flag,
    leagueCode: m.competition.code,
    country: m.competition.area?.name ?? "",
    score: m.score?.fullTime
      ? { fullTime: { home: m.score.fullTime.home, away: m.score.fullTime.away } }
      : undefined,
    odds: [],
    prediction,
    h2h: [],
  };
}

router.get("/matches", async (req, res) => {
  try {
    const fdKey = await getKey("football-data");
    if (!fdKey) {
      res.json([]);
      return;
    }

    const statusFilter = req.query["status"] as string | undefined;
    let matches: FDMatch[];

    try {
      matches = await getUpcomingMatches(fdKey, 7);
    } catch (err) {
      req.log.error({ err }, "Failed to fetch matches from Football-Data.org");
      res.json([]);
      return;
    }

    let result = matches.map(fdMatchToMatch);

    if (statusFilter) {
      result = result.filter((m) => m.status === statusFilter);
    }

    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Error in GET /matches");
    res.status(500).json({ error: "Failed to fetch matches" });
  }
});

router.get("/matches/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const fdKey = await getKey("football-data");

    if (!fdKey) {
      res.status(404).json({ error: "Ключ Football-Data.org не настроен. Добавьте его в Настройки API." });
      return;
    }

    const match = await getMatchById(fdKey, Number(id));
    if (!match) {
      res.status(404).json({ error: "Матч не найден" });
      return;
    }

    const h2hRaw = await getH2H(fdKey, Number(id));
    const h2h = h2hRaw.slice(0, 10).map((m) => ({
      date: new Date(m.utcDate).toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "2-digit" }),
      home: m.homeTeam.name,
      score: m.score?.fullTime
        ? `${m.score.fullTime.home ?? "?"}–${m.score.fullTime.away ?? "?"}`
        : "?–?",
      away: m.awayTeam.name,
      season: "",
    }));

    const base = fdMatchToMatch(match);
    res.json({ ...base, odds: [], h2h });
  } catch (err) {
    req.log.error({ err }, "Error in GET /matches/:id");
    res.status(500).json({ error: "Failed to fetch match" });
  }
});

router.get("/matches/:id/analysis", async (req, res) => {
  try {
    const { id } = req.params;
    const fdKey = await getKey("football-data");
    const openaiKey = await getKey("openai");

    if (!fdKey) {
      res.status(404).json({ error: "Ключ Football-Data.org не настроен." });
      return;
    }

    const match = await getMatchById(fdKey, Number(id));
    if (!match) {
      res.status(404).json({ error: "Матч не найден" });
      return;
    }

    const h2hRaw = await getH2H(fdKey, Number(id));

    const [homeMatches, awayMatches] = await Promise.all([
      getTeamMatches(fdKey, match.homeTeam.id, 5),
      getTeamMatches(fdKey, match.awayTeam.id, 5),
    ]);

    const toForm = (matches: FDMatch[], teamId: number): Array<"W" | "D" | "L"> =>
      matches.map((m) => {
        const isHome = m.homeTeam.id === teamId;
        const homeScore = m.score?.fullTime?.home ?? 0;
        const awayScore = m.score?.fullTime?.away ?? 0;
        if (isHome) return homeScore > awayScore ? "W" : homeScore === awayScore ? "D" : "L";
        return awayScore > homeScore ? "W" : awayScore === homeScore ? "D" : "L";
      });

    const homeForm = toForm(homeMatches, match.homeTeam.id);
    const awayForm = toForm(awayMatches, match.awayTeam.id);

    const h2h = h2hRaw.slice(0, 5).map((m) => ({
      date: new Date(m.utcDate).toLocaleDateString("ru-RU"),
      home: m.homeTeam.name,
      score: m.score?.fullTime
        ? `${m.score.fullTime.home ?? "?"}–${m.score.fullTime.away ?? "?"}`
        : "?–?",
      away: m.awayTeam.name,
    }));

    const analysis = await analyzeMatch(
      {
        homeTeam: match.homeTeam.name,
        awayTeam: match.awayTeam.name,
        league: match.competition.name,
        homeForm,
        awayForm,
        homeGoalsFor: null,
        homeGoalsAgainst: null,
        awayGoalsFor: null,
        awayGoalsAgainst: null,
        homePosition: null,
        awayPosition: null,
        h2hHistory: h2h,
        bestOddsHome: null,
        bestOddsDraw: null,
        bestOddsAway: null,
      },
      openaiKey
    );

    res.json(analysis);
  } catch (err) {
    req.log.error({ err }, "Error in GET /matches/:id/analysis");
    res.status(500).json({ error: "Failed to generate analysis" });
  }
});

router.get("/matches/:id/odds", async (req, res) => {
  res.json([]);
});

router.get("/leagues", async (req, res) => {
  res.json([
    { code: "PL", name: "Premier League", country: "England", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", emblem: "", season: "2024/25" },
    { code: "PD", name: "La Liga", country: "Spain", flag: "🇪🇸", emblem: "", season: "2024/25" },
    { code: "BL1", name: "Bundesliga", country: "Germany", flag: "🇩🇪", emblem: "", season: "2024/25" },
    { code: "SA", name: "Serie A", country: "Italy", flag: "🇮🇹", emblem: "", season: "2024/25" },
    { code: "FL1", name: "Ligue 1", country: "France", flag: "🇫🇷", emblem: "", season: "2024/25" },
    { code: "DED", name: "Eredivisie", country: "Netherlands", flag: "🇳🇱", emblem: "", season: "2024/25" },
    { code: "PPL", name: "Primeira Liga", country: "Portugal", flag: "🇵🇹", emblem: "", season: "2024/25" },
    { code: "CL", name: "Champions League", country: "Europe", flag: "🇪🇺", emblem: "", season: "2024/25" },
  ]);
});

export default router;
