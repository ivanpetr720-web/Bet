import { db } from "@workspace/db";
import { apiKeysTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

export type Provider = "football-data" | "api-football" | "odds-api" | "openai";

export async function getActiveKey(provider: Provider): Promise<string | null> {
  const keys = await db
    .select()
    .from(apiKeysTable)
    .where(and(eq(apiKeysTable.provider, provider), eq(apiKeysTable.isActive, true), eq(apiKeysTable.status, "active")))
    .limit(1);
  return keys[0]?.key ?? null;
}

export async function getAnyActiveKey(provider: Provider): Promise<string | null> {
  const keys = await db
    .select()
    .from(apiKeysTable)
    .where(and(eq(apiKeysTable.provider, provider), eq(apiKeysTable.isActive, true)))
    .limit(1);
  return keys[0]?.key ?? null;
}

export async function markKeyError(id: number, error: string): Promise<void> {
  await db
    .update(apiKeysTable)
    .set({ status: "error", lastError: error, updatedAt: new Date() })
    .where(eq(apiKeysTable.id, id));
}

export async function markKeyActive(id: number): Promise<void> {
  await db
    .update(apiKeysTable)
    .set({ status: "active", lastError: null, lastTested: new Date(), updatedAt: new Date() })
    .where(eq(apiKeysTable.id, id));
}

export async function maskKey(key: string): Promise<string> {
  if (!key || key.length < 8) return "****";
  return `${key.slice(0, 4)}${"*".repeat(Math.max(0, key.length - 8))}${key.slice(-4)}`;
}
