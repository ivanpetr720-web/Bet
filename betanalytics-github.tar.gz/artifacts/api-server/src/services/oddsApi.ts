const BASE_URL = "https://api.the-odds-api.com/v4";

export interface OddsEvent {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers: Array<{
    key: string;
    title: string;
    markets: Array<{
      key: string;
      outcomes: Array<{ name: string; price: number }>;
    }>;
  }>;
}

async function oddsFetch<T>(path: string, apiKey: string, params: Record<string, string> = {}): Promise<T> {
  const qs = new URLSearchParams({ apiKey, ...params }).toString();
  const res = await fetch(`${BASE_URL}${path}?${qs}`, {
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Odds API ${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json() as Promise<T>;
}

export async function getSoccerOdds(
  apiKey: string,
  sport = "soccer_epl",
  markets = "h2h,totals"
): Promise<OddsEvent[]> {
  return oddsFetch<OddsEvent[]>(
    `/sports/${sport}/odds`,
    apiKey,
    { markets, oddsFormat: "decimal", regions: "eu" }
  );
}

export function extractBookmakerOdds(event: OddsEvent): Array<{
  bookmaker: string;
  home: number | null;
  draw: number | null;
  away: number | null;
  btts: number | null;
  over25: number | null;
}> {
  return event.bookmakers.slice(0, 4).map((bm) => {
    const h2h = bm.markets.find((m) => m.key === "h2h");
    const totals = bm.markets.find((m) => m.key === "totals");

    const home = h2h?.outcomes.find((o) => o.name === event.home_team)?.price ?? null;
    const away = h2h?.outcomes.find((o) => o.name === event.away_team)?.price ?? null;
    const draw = h2h?.outcomes.find((o) => o.name === "Draw")?.price ?? null;
    const over25 = totals?.outcomes.find((o) => o.name === "Over" && o.name.includes("2.5"))?.price ?? null;

    return { bookmaker: bm.title, home, draw, away, btts: null, over25 };
  });
}

export async function getApiUsage(apiKey: string): Promise<{ used: number; remaining: number } | null> {
  try {
    const res = await fetch(`${BASE_URL}/sports?apiKey=${apiKey}`, { signal: AbortSignal.timeout(5000) });
    const used = Number(res.headers.get("x-requests-used")) || 0;
    const remaining = Number(res.headers.get("x-requests-remaining")) || 0;
    return { used, remaining: remaining + used };
  } catch {
    return null;
  }
}
