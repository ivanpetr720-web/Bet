import OpenAI from "openai";

const REPLIT_AI_BASE = "https://ai-proxy.replit.com";

interface MatchContext {
  homeTeam: string;
  awayTeam: string;
  league: string;
  homeForm: string[];
  awayForm: string[];
  homeGoalsFor: number | null;
  homeGoalsAgainst: number | null;
  awayGoalsFor: number | null;
  awayGoalsAgainst: number | null;
  homePosition: number | null;
  awayPosition: number | null;
  h2hHistory: Array<{ date: string; home: string; score: string; away: string }>;
  bestOddsHome: number | null;
  bestOddsDraw: number | null;
  bestOddsAway: number | null;
}

export interface AIAnalysisResult {
  outcome: "home" | "draw" | "away";
  confidence: number;
  scoreline: string;
  btts: boolean;
  over25: boolean;
  riskScore: number;
  riskLevel: "low" | "medium" | "high";
  aiInsight: string;
  reasoning: string[];
  tips: Array<{ label: string; odds: number; value: number; confidence: number }>;
  recommendation: "bet" | "skip" | "watch";
}

function buildClient(userApiKey?: string | null): OpenAI {
  if (userApiKey) {
    return new OpenAI({ apiKey: userApiKey });
  }
  return new OpenAI({
    apiKey: process.env["REPLIT_AI_API_KEY"] ?? "replit",
    baseURL: REPLIT_AI_BASE,
  });
}

function buildFormString(form: string[]): string {
  return form.length > 0 ? form.join("-") : "Unknown";
}

function localFallbackAnalysis(ctx: MatchContext): AIAnalysisResult {
  const homeFormScore = ctx.homeForm.reduce((s, r) => s + (r === "W" ? 3 : r === "D" ? 1 : 0), 0);
  const awayFormScore = ctx.awayForm.reduce((s, r) => s + (r === "W" ? 3 : r === "D" ? 1 : 0), 0);
  const totalForm = homeFormScore + awayFormScore;

  let outcome: "home" | "draw" | "away" = "home";
  let confidence = 55;

  if (homeFormScore > awayFormScore + 3) {
    outcome = "home";
    confidence = 60 + Math.min(homeFormScore - awayFormScore, 20);
  } else if (awayFormScore > homeFormScore + 3) {
    outcome = "away";
    confidence = 60 + Math.min(awayFormScore - homeFormScore, 20);
  } else {
    outcome = "draw";
    confidence = 50 + Math.abs(homeFormScore - awayFormScore);
  }

  const riskScore = Math.max(1, Math.min(10, 10 - Math.floor(confidence / 10)));
  const riskLevel: "low" | "medium" | "high" = riskScore <= 3 ? "low" : riskScore <= 6 ? "medium" : "high";

  const reasoning: string[] = [];
  if (ctx.homeForm.length > 0) reasoning.push(`${ctx.homeTeam} recent form: ${buildFormString(ctx.homeForm)}`);
  if (ctx.awayForm.length > 0) reasoning.push(`${ctx.awayTeam} recent form: ${buildFormString(ctx.awayForm)}`);
  if (ctx.homePosition) reasoning.push(`${ctx.homeTeam} table position: ${ctx.homePosition}`);
  if (ctx.awayPosition) reasoning.push(`${ctx.awayTeam} table position: ${ctx.awayPosition}`);
  if (ctx.h2hHistory.length > 0) reasoning.push(`Last H2H: ${ctx.h2hHistory[0].home} ${ctx.h2hHistory[0].score} ${ctx.h2hHistory[0].away}`);

  const tips: AIAnalysisResult["tips"] = [];
  const bestOdds = outcome === "home" ? ctx.bestOddsHome : outcome === "away" ? ctx.bestOddsAway : ctx.bestOddsDraw;
  if (bestOdds) {
    const impliedProb = 1 / bestOdds;
    const ourProb = confidence / 100;
    const value = Math.round((ourProb - impliedProb) * 100) / 100;
    tips.push({
      label: outcome === "home" ? `${ctx.homeTeam} Win` : outcome === "away" ? `${ctx.awayTeam} Win` : "Draw",
      odds: bestOdds,
      value,
      confidence,
    });
  }
  if (ctx.bestOddsHome && ctx.bestOddsAway) {
    tips.push({ label: "Both Teams to Score", odds: 1.75, value: 0.05, confidence: 58 });
    tips.push({ label: "Over 2.5 Goals", odds: 1.65, value: 0.04, confidence: 55 });
  }

  return {
    outcome,
    confidence,
    scoreline: outcome === "home" ? "2-1" : outcome === "away" ? "1-2" : "1-1",
    btts: totalForm > 10,
    over25: totalForm > 12,
    riskScore,
    riskLevel,
    aiInsight: `Analysis based on recent form: ${ctx.homeTeam} (${buildFormString(ctx.homeForm)}) vs ${ctx.awayTeam} (${buildFormString(ctx.awayForm)}). Statistical model predicts ${outcome === "home" ? ctx.homeTeam : outcome === "away" ? ctx.awayTeam : "a draw"} with ${confidence}% confidence.`,
    reasoning,
    tips,
    recommendation: confidence >= 65 && riskScore <= 5 ? "bet" : confidence >= 55 ? "watch" : "skip",
  };
}

export async function analyzeMatch(ctx: MatchContext, openaiApiKey?: string | null): Promise<AIAnalysisResult> {
  try {
    const client = buildClient(openaiApiKey);

    const prompt = `You are an expert sports betting analyst. Analyze this football match and provide a structured prediction.

Match: ${ctx.homeTeam} vs ${ctx.awayTeam}
League: ${ctx.league}
${ctx.homePosition ? `${ctx.homeTeam} table position: ${ctx.homePosition}` : ""}
${ctx.awayPosition ? `${ctx.awayTeam} table position: ${ctx.awayPosition}` : ""}
${ctx.homeGoalsFor !== null ? `${ctx.homeTeam} goals for/against: ${ctx.homeGoalsFor}/${ctx.homeGoalsAgainst}` : ""}
${ctx.awayGoalsFor !== null ? `${ctx.awayTeam} goals for/against: ${ctx.awayGoalsFor}/${ctx.awayGoalsAgainst}` : ""}
${ctx.homeForm.length ? `${ctx.homeTeam} last 5 results: ${buildFormString(ctx.homeForm)} (W=win, D=draw, L=loss, most recent first)` : ""}
${ctx.awayForm.length ? `${ctx.awayTeam} last 5 results: ${buildFormString(ctx.awayForm)}` : ""}
${ctx.h2hHistory.length ? `Head-to-head (last ${Math.min(ctx.h2hHistory.length, 5)}): ${ctx.h2hHistory.slice(0, 5).map((h) => `${h.date}: ${h.home} ${h.score} ${h.away}`).join(", ")}` : ""}
${ctx.bestOddsHome ? `Market odds — Home: ${ctx.bestOddsHome}, Draw: ${ctx.bestOddsDraw}, Away: ${ctx.bestOddsAway}` : ""}

Respond with a JSON object (no markdown):
{
  "outcome": "home" | "draw" | "away",
  "confidence": <integer 40-90>,
  "scoreline": "<predicted score like 2-1>",
  "btts": <boolean>,
  "over25": <boolean>,
  "riskScore": <integer 1-10>,
  "riskLevel": "low" | "medium" | "high",
  "aiInsight": "<2-3 sentence professional insight in English>",
  "reasoning": ["<point 1>", "<point 2>", "<point 3>", "<point 4>"],
  "tips": [
    {"label": "<bet label>", "odds": <number>, "value": <edge 0-0.3>, "confidence": <40-90>}
  ],
  "recommendation": "bet" | "skip" | "watch"
}`;

    const response = await client.chat.completions.create({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
      max_tokens: 800,
    });

    const text = response.choices[0]?.message?.content ?? "";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("No JSON in AI response");

    const parsed = JSON.parse(jsonMatch[0]) as AIAnalysisResult;
    return {
      outcome: parsed.outcome ?? "home",
      confidence: Math.min(90, Math.max(40, parsed.confidence ?? 55)),
      scoreline: parsed.scoreline ?? "1-1",
      btts: Boolean(parsed.btts),
      over25: Boolean(parsed.over25),
      riskScore: Math.min(10, Math.max(1, parsed.riskScore ?? 5)),
      riskLevel: parsed.riskLevel ?? "medium",
      aiInsight: parsed.aiInsight ?? "",
      reasoning: Array.isArray(parsed.reasoning) ? parsed.reasoning.slice(0, 6) : [],
      tips: Array.isArray(parsed.tips) ? parsed.tips.slice(0, 4) : [],
      recommendation: parsed.recommendation ?? "watch",
    };
  } catch {
    return localFallbackAnalysis(ctx);
  }
}
