const BASE_URL = "https://api.football-data.org/v4";

export interface FDMatch {
  id: number;
  utcDate: string;
  status: string;
  homeTeam: { id: number; name: string; shortName: string; tla: string; crest: string };
  awayTeam: { id: number; name: string; shortName: string; tla: string; crest: string };
  score: {
    fullTime?: { home: number | null; away: number | null };
    halfTime?: { home: number | null; away: number | null };
  };
  competition: { id: number; name: string; code: string; emblem: string; area: { name: string; flag: string } };
  matchday?: number;
}

export interface FDStandings {
  table: Array<{
    position: number;
    team: { id: number; name: string; shortName: string; tla: string; crest: string };
    playedGames: number;
    won: number;
    draw: number;
    lost: number;
    points: number;
    goalsFor: number;
    goalsAgainst: number;
    goalDifference: number;
    form: string | null;
  }>;
}

const COMPETITION_FLAGS: Record<string, string> = {
  PL: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
  PD: "🇪🇸",
  BL1: "🇩🇪",
  SA: "🇮🇹",
  FL1: "🇫🇷",
  PPL: "🇵🇹",
  DED: "🇳🇱",
  BSA: "🇧🇷",
  CL: "🇪🇺",
  EL: "🇪🇺",
  WC: "🌍",
};

async function fdFetch<T>(path: string, apiKey: string): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "X-Auth-Token": apiKey },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`FD API ${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json() as Promise<T>;
}

export async function getTodayMatches(apiKey: string): Promise<FDMatch[]> {
  const today = new Date().toISOString().split("T")[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];
  const data = await fdFetch<{ matches: FDMatch[] }>(`/matches?dateFrom=${today}&dateTo=${tomorrow}`, apiKey);
  return data.matches ?? [];
}

export async function getUpcomingMatches(apiKey: string, days = 7): Promise<FDMatch[]> {
  const today = new Date().toISOString().split("T")[0];
  const future = new Date(Date.now() + days * 86400000).toISOString().split("T")[0];
  const data = await fdFetch<{ matches: FDMatch[] }>(`/matches?dateFrom=${today}&dateTo=${future}`, apiKey);
  return data.matches ?? [];
}

export async function getMatchById(apiKey: string, fdId: number): Promise<FDMatch | null> {
  try {
    const data = await fdFetch<FDMatch>(`/matches/${fdId}`, apiKey);
    return data;
  } catch {
    return null;
  }
}

export async function getH2H(apiKey: string, fdId: number): Promise<FDMatch[]> {
  try {
    const data = await fdFetch<{ matches: FDMatch[] }>(`/matches/${fdId}/head2head?limit=10`, apiKey);
    return data.matches ?? [];
  } catch {
    return [];
  }
}

export async function getCompetitionStandings(apiKey: string, competitionCode: string): Promise<FDStandings | null> {
  try {
    const data = await fdFetch<{ standings: FDStandings[] }>(`/competitions/${competitionCode}/standings`, apiKey);
    return data.standings?.[0] ?? null;
  } catch {
    return null;
  }
}

export async function getTeamMatches(apiKey: string, teamId: number, limit = 10): Promise<FDMatch[]> {
  try {
    const data = await fdFetch<{ matches: FDMatch[] }>(`/teams/${teamId}/matches?limit=${limit}&status=FINISHED`, apiKey);
    return data.matches ?? [];
  } catch {
    return [];
  }
}

export function normalizeFDStatus(status: string): "upcoming" | "live" | "finished" {
  if (["SCHEDULED", "TIMED", "POSTPONED"].includes(status)) return "upcoming";
  if (["IN_PLAY", "PAUSED", "LIVE"].includes(status)) return "live";
  return "finished";
}

export function getCompetitionFlag(code: string): string {
  return COMPETITION_FLAGS[code] ?? "🏆";
}
