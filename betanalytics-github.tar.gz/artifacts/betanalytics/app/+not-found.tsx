import { Feather } from "@expo/vector-icons";
import { Link, Stack } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

export default function NotFoundScreen() {
  const colors = useColors();

  return (
    <>
      <Stack.Screen options={{ title: "Не найдено" }} />
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Feather name="alert-circle" size={56} color={colors.mutedForeground} />
        <Text style={[styles.title, { color: colors.foreground }]}>Страница не найдена</Text>
        <Link href="/" style={styles.link}>
          <Text style={[styles.linkText, { color: colors.primary }]}>
            На главную
          </Text>
        </Link>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center", gap: 14 },
  title: { fontSize: 18, fontFamily: "Inter_600SemiBold" },
  link: { marginTop: 6 },
  linkText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
});
