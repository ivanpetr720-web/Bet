import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { MatchCard } from "@/components/MatchCard";
import { TeamLogo } from "@/components/TeamLogo";
import { FormBadges } from "@/components/FormBadges";
import { SkeletonCard } from "@/components/SkeletonCard";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { useMatches } from "@/hooks/useMatches";
import { router } from "expo-router";

type FavTab = "matches" | "teams" | "leagues";

export default function FavoritesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { favorites, favTeams, favLeagues, toggleFavTeam, toggleFavLeague, isFavTeam, isFavLeague } = useApp();
  const { data: matches, isLoading, refetch, isFetching } = useMatches();
  const [tab, setTab] = useState<FavTab>("matches");

  const favMatches = useMemo(
    () => (matches ?? []).filter((m) => favorites.includes(m.id)),
    [matches, favorites]
  );

  const allTeams = useMemo(() => {
    if (!matches) return [];
    const seen = new Set<string>();
    const teams: { name: string; shortName: string; crest: string; tla: string; league: string; form: ("W"|"D"|"L")[] }[] = [];
    for (const m of matches) {
      if (!seen.has(m.homeTeam.name)) {
        seen.add(m.homeTeam.name);
        teams.push({ name: m.homeTeam.name, shortName: m.homeTeam.shortName, crest: m.homeTeam.crest, tla: m.homeTeam.tla, league: m.league, form: m.homeTeam.form });
      }
      if (!seen.has(m.awayTeam.name)) {
        seen.add(m.awayTeam.name);
        teams.push({ name: m.awayTeam.name, shortName: m.awayTeam.shortName, crest: m.awayTeam.crest, tla: m.awayTeam.tla, league: m.league, form: m.awayTeam.form });
      }
    }
    return teams;
  }, [matches]);

  const allLeagues = useMemo(() => {
    if (!matches) return [];
    const seen = new Set<string>();
    const leagues: { code: string; name: string; flag: string; count: number }[] = [];
    for (const m of matches) {
      if (!seen.has(m.leagueCode)) {
        seen.add(m.leagueCode);
        leagues.push({ code: m.leagueCode, name: m.league, flag: m.leagueFlag, count: matches.filter((mm) => mm.leagueCode === m.leagueCode).length });
      }
    }
    return leagues;
  }, [matches]);

  const favTeamItems = useMemo(() => allTeams.filter((t) => isFavTeam(t.name)), [allTeams, favTeams]);
  const favLeagueItems = useMemo(() => allLeagues.filter((l) => isFavLeague(l.code)), [allLeagues, favLeagues]);

  const tabs: { id: FavTab; label: string; count: number }[] = [
    { id: "matches", label: "Матчи", count: favMatches.length },
    { id: "teams", label: "Команды", count: favTeamItems.length },
    { id: "leagues", label: "Лиги", count: favLeagueItems.length },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, {
        paddingTop: Platform.OS === "web" ? 67 : insets.top + 12,
        backgroundColor: colors.background, borderBottomColor: colors.border,
      }]}>
        <Text style={[styles.title, { color: colors.foreground }]}>Избранное</Text>
        <View style={styles.tabRow}>
          {tabs.map((t) => (
            <TouchableOpacity
              key={t.id}
              style={[styles.tabBtn, tab === t.id ? { borderBottomColor: colors.primary } : { borderBottomColor: "transparent" }]}
              onPress={() => setTab(t.id)}
            >
              <Text style={[styles.tabText, { color: tab === t.id ? colors.primary : colors.mutedForeground }]}>
                {t.label}
              </Text>
              {t.count > 0 && (
                <View style={[styles.countBadge, { backgroundColor: colors.primary }]}>
                  <Text style={[styles.countText, { color: colors.primaryForeground }]}>{t.count}</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {tab === "matches" && (
        isLoading ? (
          <View style={styles.list}>
            {[1, 2].map((i) => <SkeletonCard key={i} />)}
          </View>
        ) : (
          <FlatList
            data={favMatches}
            keyExtractor={(m) => m.id}
            showsVerticalScrollIndicator={false}
            refreshControl={<RefreshControl refreshing={isFetching && !isLoading} onRefresh={refetch} tintColor={colors.primary} />}
            contentContainerStyle={[styles.list, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
            renderItem={({ item, index }) => <MatchCard match={item} index={index} />}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Feather name="bookmark" size={40} color={colors.mutedForeground} />
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Нет избранных матчей</Text>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  Нажмите на закладку в карточке матча
                </Text>
                <TouchableOpacity
                  onPress={() => router.push("/")}
                  style={[styles.goBtn, { backgroundColor: colors.primary }]}
                >
                  <Text style={[styles.goBtnText, { color: colors.primaryForeground }]}>К матчам</Text>
                </TouchableOpacity>
              </View>
            }
          />
        )
      )}

      {tab === "teams" && (
        <FlatList
          data={tab === "teams" ? (favTeamItems.length > 0 ? favTeamItems : allTeams) : []}
          keyExtractor={(t) => t.name}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.list, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
          ListHeaderComponent={
            allTeams.length > 0 && favTeamItems.length === 0 ? (
              <Text style={[styles.sectionHint, { color: colors.mutedForeground }]}>
                Нажмите на звезду, чтобы добавить команду в избранное
              </Text>
            ) : null
          }
          renderItem={({ item }) => {
            const isFav = isFavTeam(item.name);
            return (
              <View style={[styles.teamRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <TeamLogo crest={item.crest} tla={item.tla} size={44} />
                <View style={styles.teamInfo}>
                  <Text style={[styles.teamName, { color: colors.foreground }]}>{item.shortName}</Text>
                  <Text style={[styles.teamLeague, { color: colors.mutedForeground }]}>{item.league}</Text>
                  <FormBadges form={item.form} size="sm" />
                </View>
                <TouchableOpacity
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    toggleFavTeam(item.name);
                  }}
                  hitSlop={10}
                >
                  <Feather name="star" size={20} color={isFav ? colors.gold : colors.mutedForeground} />
                </TouchableOpacity>
              </View>
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="users" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Нет команд</Text>
            </View>
          }
        />
      )}

      {tab === "leagues" && (
        <FlatList
          data={tab === "leagues" ? (favLeagueItems.length > 0 ? favLeagueItems : allLeagues) : []}
          keyExtractor={(l) => l.code}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.list, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
          ListHeaderComponent={
            allLeagues.length > 0 && favLeagueItems.length === 0 ? (
              <Text style={[styles.sectionHint, { color: colors.mutedForeground }]}>
                Нажмите на звезду, чтобы добавить лигу в избранное
              </Text>
            ) : null
          }
          renderItem={({ item }) => {
            const isFav = isFavLeague(item.code);
            return (
              <View style={[styles.leagueRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={styles.leagueFlag}>{item.flag}</Text>
                <View style={styles.leagueInfo}>
                  <Text style={[styles.leagueName, { color: colors.foreground }]}>{item.name}</Text>
                  <Text style={[styles.leagueCount, { color: colors.mutedForeground }]}>{item.count} матчей</Text>
                </View>
                <TouchableOpacity
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    toggleFavLeague(item.code);
                  }}
                  hitSlop={10}
                >
                  <Feather name="star" size={20} color={isFav ? colors.gold : colors.mutedForeground} />
                </TouchableOpacity>
              </View>
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="globe" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Нет лиг</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 0, borderBottomWidth: 1 },
  title: { fontSize: 24, fontFamily: "Inter_700Bold", marginBottom: 12 },
  tabRow: { flexDirection: "row" },
  tabBtn: { flexDirection: "row", alignItems: "center", gap: 6, flex: 1, justifyContent: "center", paddingVertical: 10, borderBottomWidth: 2 },
  tabText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  countBadge: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 100 },
  countText: { fontSize: 10, fontFamily: "Inter_700Bold" },
  list: { paddingHorizontal: 16, paddingTop: 12 },
  empty: { alignItems: "center", paddingTop: 80, gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", paddingHorizontal: 20 },
  goBtn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 4 },
  goBtnText: { fontSize: 14, fontFamily: "Inter_700Bold" },
  sectionHint: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center", marginBottom: 12 },
  teamRow: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 14, borderWidth: 1, padding: 14, marginBottom: 10 },
  teamInfo: { flex: 1, gap: 4 },
  teamName: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  teamLeague: { fontSize: 12, fontFamily: "Inter_400Regular" },
  leagueRow: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 14, borderWidth: 1, padding: 14, marginBottom: 10 },
  leagueFlag: { fontSize: 32 },
  leagueInfo: { flex: 1, gap: 2 },
  leagueName: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  leagueCount: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
