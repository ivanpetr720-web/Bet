import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useMemo, useState } from "react";
import {
  Platform,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { TeamLogo } from "@/components/TeamLogo";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { useMatches, type LiveMatch } from "@/hooks/useMatches";

type MktFilter = "main" | "goals";

export default function CompareScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data: matches, isLoading, refetch, isFetching } = useMatches();
  const { trackOdds, removeTracked, isTracked } = useApp();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [mktFilter, setMktFilter] = useState<MktFilter>("main");

  const match: LiveMatch | undefined = useMemo(() => {
    if (!matches) return undefined;
    const target = selectedId ?? matches[0]?.id;
    return matches.find((m) => m.id === target) ?? matches[0];
  }, [matches, selectedId]);

  const getBest = (key: "home" | "draw" | "away" | "btts" | "over25") =>
    match ? Math.max(...match.odds.map((b) => b[key] ?? 0).filter(Boolean)) : 0;

  const marketKeys = mktFilter === "main"
    ? (["home", "draw", "away"] as const)
    : (["btts", "over25"] as const);

  const marketLabel: Record<string, string> = {
    home: `П1 (${match?.homeTeam.shortName ?? "Хозяева"})`,
    draw: "Ничья (Х)",
    away: `П2 (${match?.awayTeam.shortName ?? "Гости"})`,
    btts: "Обе забьют",
    over25: "Тотал > 2.5",
  };

  const handleTrackOdds = (key: string, odds: number) => {
    if (!match) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const betLabel = `${marketLabel[key]} @ ${odds.toFixed(2)}`;
    if (isTracked(match.id, betLabel)) {
      removeTracked(match.id, betLabel);
    } else {
      trackOdds({
        matchId: match.id,
        matchTitle: `${match.homeTeam.shortName} – ${match.awayTeam.shortName}`,
        betLabel,
        initialOdds: odds,
        currentOdds: odds,
      });
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, {
        paddingTop: Platform.OS === "web" ? 67 : insets.top + 12,
        backgroundColor: colors.background, borderBottomColor: colors.border,
      }]}>
        <Text style={[styles.title, { color: colors.foreground }]}>Сравнение</Text>
        <Text style={[styles.sub, { color: colors.mutedForeground }]}>Лучший кэф у букмекеров</Text>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={isFetching && !isLoading} onRefresh={refetch} tintColor={colors.primary} />}
        contentContainerStyle={[styles.content, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
      >
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.matchScroll}>
          {(matches ?? []).map((m) => {
            const isSelected = (selectedId ?? matches?.[0]?.id) === m.id;
            return (
              <TouchableOpacity
                key={m.id}
                style={[styles.matchChip, isSelected
                  ? { backgroundColor: colors.primary + "22", borderColor: colors.primary }
                  : { backgroundColor: colors.surface, borderColor: colors.border }]}
                onPress={() => setSelectedId(m.id)}
              >
                <View style={styles.chipLogos}>
                  <TeamLogo crest={m.homeTeam.crest} tla={m.homeTeam.tla} size={16} />
                  <Text style={{ fontSize: 10, color: colors.mutedForeground }}>–</Text>
                  <TeamLogo crest={m.awayTeam.crest} tla={m.awayTeam.tla} size={16} />
                </View>
                <Text style={[styles.chipText, { color: isSelected ? colors.primary : colors.mutedForeground }]} numberOfLines={1}>
                  {m.homeTeam.tla}–{m.awayTeam.tla}
                </Text>
                <Text style={{ fontSize: 12 }}>{m.leagueFlag}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {match && (
          <>
            <View style={[styles.matchInfo, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.matchInfoTeams}>
                <View style={styles.miniTeam}>
                  <TeamLogo crest={match.homeTeam.crest} tla={match.homeTeam.tla} size={36} />
                  <Text style={[styles.miniTeamName, { color: colors.foreground }]} numberOfLines={1}>
                    {match.homeTeam.shortName}
                  </Text>
                </View>
                <View style={styles.matchInfoCentre}>
                  <Text style={[styles.matchInfoLeague, { color: colors.mutedForeground }]}>
                    {match.leagueFlag} {match.league}
                  </Text>
                  <Text style={[styles.matchInfoTime, { color: colors.primary }]}>
                    {match.date} · {match.time}
                  </Text>
                  <Text style={[styles.predScore, { color: colors.foreground }]}>
                    {match.prediction.scoreline}
                  </Text>
                </View>
                <View style={[styles.miniTeam, styles.miniTeamRight]}>
                  <TeamLogo crest={match.awayTeam.crest} tla={match.awayTeam.tla} size={36} />
                  <Text style={[styles.miniTeamName, { color: colors.foreground }]} numberOfLines={1}>
                    {match.awayTeam.shortName}
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.mktRow}>
              {[{ id: "main" as const, label: "Исход" }, { id: "goals" as const, label: "Голы" }].map((f) => (
                <TouchableOpacity
                  key={f.id}
                  style={[styles.mktBtn, mktFilter === f.id
                    ? { backgroundColor: colors.primary, borderColor: colors.primary }
                    : { backgroundColor: colors.surface, borderColor: colors.border }]}
                  onPress={() => setMktFilter(f.id)}
                >
                  <Text style={[styles.mktText, { color: mktFilter === f.id ? colors.primaryForeground : colors.mutedForeground }]}>
                    {f.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {match.odds.length === 0 ? (
              <View style={[styles.noOdds, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[styles.noOddsText, { color: colors.mutedForeground }]}>
                  Коэффициенты недоступны
                </Text>
              </View>
            ) : (
              marketKeys.map((key) => {
                const best = getBest(key);
                const sorted = [...match.odds]
                  .filter((b) => (b[key] ?? 0) > 0)
                  .sort((a, b) => (b[key] ?? 0) - (a[key] ?? 0));
                if (!sorted.length) return null;
                const tracked = isTracked(match.id, `${marketLabel[key]} @ ${best.toFixed(2)}`);
                return (
                  <View key={key} style={styles.mktSection}>
                    <View style={styles.mktHeader}>
                      <Text style={[styles.mktTitle, { color: colors.foreground }]}>{marketLabel[key]}</Text>
                      <View style={styles.mktRight}>
                        <TouchableOpacity
                          onPress={() => handleTrackOdds(key, best)}
                          style={[styles.trackBtn, {
                            backgroundColor: tracked ? colors.primary + "22" : colors.surface,
                            borderColor: tracked ? colors.primary : colors.border,
                          }]}
                        >
                          <Feather name={tracked ? "bell-off" : "bell"} size={11} color={tracked ? colors.primary : colors.mutedForeground} />
                          <Text style={[styles.trackText, { color: tracked ? colors.primary : colors.mutedForeground }]}>
                            {tracked ? "Отслеж." : "Следить"}
                          </Text>
                        </TouchableOpacity>
                        <View style={[styles.bestPill, { backgroundColor: colors.primary + "22", borderColor: colors.primary + "45" }]}>
                          <Text style={[styles.bestPillText, { color: colors.primary }]}>Лучший: {best.toFixed(2)}</Text>
                        </View>
                      </View>
                    </View>
                    {sorted.map((b, i) => {
                      const val = b[key] ?? 0;
                      const pct = best > 0 ? (val / best) * 100 : 100;
                      const isTop = i === 0;
                      return (
                        <View key={b.bookmaker} style={[styles.bookRow, {
                          backgroundColor: isTop ? colors.primary + "10" : colors.card,
                          borderColor: isTop ? colors.primary + "40" : colors.border,
                        }]}>
                          <View style={[styles.bookIcon, { backgroundColor: colors.surface }]}>
                            <Text style={[styles.bookIconText, { color: isTop ? colors.primary : colors.mutedForeground }]}>
                              {b.bookmaker.slice(0, 3).toUpperCase()}
                            </Text>
                          </View>
                          <View style={styles.bookInfo}>
                            <View style={styles.bookNameRow}>
                              <Text style={[styles.bookName, { color: colors.foreground }]}>{b.bookmaker}</Text>
                              {isTop && (
                                <View style={[styles.topTag, { backgroundColor: colors.primary }]}>
                                  <Text style={[styles.topTagText, { color: colors.primaryForeground }]}>ЛУЧШИЙ</Text>
                                </View>
                              )}
                            </View>
                            <View style={[styles.barTrack, { backgroundColor: colors.surface }]}>
                              <View style={[styles.barFill, {
                                width: `${pct}%` as `${number}%`,
                                backgroundColor: isTop ? colors.primary : colors.mutedForeground,
                              }]} />
                            </View>
                          </View>
                          <Text style={[styles.bookOdds, { color: isTop ? colors.primary : colors.foreground }]}>
                            {val.toFixed(2)}
                          </Text>
                        </View>
                      );
                    })}
                  </View>
                );
              })
            )}

            {match.prediction.tips.filter((t) => t.value > 0.08).length > 0 && (
              <View style={styles.valueSection}>
                <Text style={[styles.valueSectionTitle, { color: colors.foreground }]}>Value прогнозы</Text>
                {match.prediction.tips.filter((t) => t.value > 0.08).map((tip, i) => (
                  <View key={i} style={[styles.dealRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
                    <View style={styles.dealLeft}>
                      <View style={[styles.valuePill, { backgroundColor: colors.primary + "22", borderColor: colors.primary + "40" }]}>
                        <Text style={[styles.valuePillText, { color: colors.primary }]}>
                          VALUE +{(tip.value * 100).toFixed(0)}%
                        </Text>
                      </View>
                      <Text style={[styles.dealLabel, { color: colors.foreground }]}>{tip.label}</Text>
                      <Text style={[styles.dealConf, { color: colors.mutedForeground }]}>
                        Уверенность: {tip.confidence}%
                      </Text>
                    </View>
                    <Text style={[styles.dealOdds, { color: colors.primary }]}>{tip.odds.toFixed(2)}</Text>
                  </View>
                ))}
              </View>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: 1 },
  title: { fontSize: 24, fontFamily: "Inter_700Bold" },
  sub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  content: { paddingHorizontal: 16, paddingTop: 12, gap: 12 },
  matchScroll: { gap: 8, paddingBottom: 4 },
  matchChip: { borderRadius: 12, borderWidth: 1, padding: 8, gap: 3, alignItems: "center", minWidth: 72 },
  chipLogos: { flexDirection: "row", alignItems: "center", gap: 2 },
  chipText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
  matchInfo: { borderRadius: 14, borderWidth: 1, padding: 14 },
  matchInfoTeams: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  miniTeam: { alignItems: "flex-start", gap: 4, flex: 1 },
  miniTeamRight: { alignItems: "flex-end" },
  miniTeamName: { fontSize: 12, fontFamily: "Inter_600SemiBold", maxWidth: 90 },
  matchInfoCentre: { alignItems: "center", gap: 2 },
  matchInfoLeague: { fontSize: 10, fontFamily: "Inter_400Regular" },
  matchInfoTime: { fontSize: 13, fontFamily: "Inter_700Bold" },
  predScore: { fontSize: 18, fontFamily: "Inter_700Bold" },
  mktRow: { flexDirection: "row", gap: 8 },
  mktBtn: { flex: 1, alignItems: "center", paddingVertical: 8, borderRadius: 100, borderWidth: 1 },
  mktText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  noOdds: { borderRadius: 14, borderWidth: 1, padding: 20, alignItems: "center" },
  noOddsText: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center" },
  mktSection: { gap: 8 },
  mktHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  mktRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  mktTitle: { fontSize: 14, fontFamily: "Inter_700Bold" },
  trackBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 100, borderWidth: 1 },
  trackText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
  bestPill: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 100, borderWidth: 1 },
  bestPillText: { fontSize: 11, fontFamily: "Inter_700Bold" },
  bookRow: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 12, borderWidth: 1, padding: 10 },
  bookIcon: { width: 36, height: 36, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  bookIconText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  bookInfo: { flex: 1, gap: 5 },
  bookNameRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  bookName: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  topTag: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  topTagText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  barTrack: { height: 4, borderRadius: 100, overflow: "hidden" },
  barFill: { height: 4, borderRadius: 100 },
  bookOdds: { fontSize: 20, fontFamily: "Inter_700Bold", minWidth: 46, textAlign: "right" },
  valueSection: { gap: 8 },
  valueSectionTitle: { fontSize: 15, fontFamily: "Inter_700Bold" },
  dealRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 14, borderWidth: 1, padding: 14 },
  dealLeft: { flex: 1, gap: 5 },
  valuePill: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 100, borderWidth: 1 },
  valuePillText: { fontSize: 10, fontFamily: "Inter_700Bold" },
  dealLabel: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  dealConf: { fontSize: 11, fontFamily: "Inter_400Regular" },
  dealOdds: { fontSize: 24, fontFamily: "Inter_700Bold" },
});
