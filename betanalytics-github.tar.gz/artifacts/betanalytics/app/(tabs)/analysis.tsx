import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ConfidenceBar } from "@/components/ConfidenceBar";
import { RiskBadge } from "@/components/RiskBadge";
import { SkeletonCard } from "@/components/SkeletonCard";
import { TeamLogo } from "@/components/TeamLogo";
import { useColors } from "@/hooks/useColors";
import { useMatches, type LiveMatch } from "@/hooks/useMatches";

type FilterMode = "all" | "high" | "value" | "low_risk";

export default function AnalysisScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data: matches, isLoading, refetch, isFetching } = useMatches();
  const [filter, setFilter] = useState<FilterMode>("all");

  const accuracy = useMemo(() => {
    if (!matches) return null;
    const finished = matches.filter((m) => m.status === "finished" && m.score?.fullTime?.home != null);
    if (!finished.length) return null;
    const correct = finished.filter((m) => {
      const h = m.score!.fullTime!.home!;
      const a = m.score!.fullTime!.away!;
      const actual = h > a ? "home" : a > h ? "away" : "draw";
      return actual === m.prediction.outcome;
    });
    return { pct: Math.round((correct.length / finished.length) * 100), correct: correct.length, total: finished.length };
  }, [matches]);

  const filtered = useMemo(() => {
    if (!matches) return [];
    return matches
      .filter((m) => {
        if (filter === "high") return m.prediction.confidence >= 65;
        if (filter === "value") return (m.prediction.tips[0]?.value ?? 0) > 0.10;
        if (filter === "low_risk") return m.prediction.riskLevel === "low";
        return true;
      })
      .sort((a, b) => b.prediction.confidence - a.prediction.confidence);
  }, [matches, filter]);

  const filters: { id: FilterMode; label: string; icon: string }[] = [
    { id: "all", label: "Все", icon: "list" },
    { id: "high", label: "≥65%", icon: "trending-up" },
    { id: "value", label: "VALUE", icon: "zap" },
    { id: "low_risk", label: "Низкий риск", icon: "shield" },
  ];

  const renderCard = ({ item }: { item: LiveMatch }) => {
    const isFinished = item.status === "finished";
    const isLive = item.status === "live";
    const actualOutcome = isFinished && item.score?.fullTime
      ? (item.score.fullTime.home! > item.score.fullTime.away! ? "home"
        : item.score.fullTime.home! < item.score.fullTime.away! ? "away" : "draw")
      : null;
    const isCorrect = actualOutcome === item.prediction.outcome;

    return (
      <TouchableOpacity
        activeOpacity={0.88}
        style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}
        onPress={() => router.push(`/match/${item.id}`)}
      >
        <View style={styles.cardHeader}>
          <View style={styles.leagueRow}>
            <Text style={styles.leagueFlag}>{item.leagueFlag}</Text>
            <Text style={[styles.cardLeague, { color: colors.mutedForeground }]}>{item.league}</Text>
          </View>
          <View style={styles.cardHeaderRight}>
            {isLive && (
              <View style={[styles.livePill, { backgroundColor: colors.loss + "22", borderColor: colors.loss }]}>
                <View style={[styles.liveDot, { backgroundColor: colors.loss }]} />
                <Text style={[styles.liveText, { color: colors.loss }]}>LIVE</Text>
              </View>
            )}
            {isFinished && (
              <View style={[styles.resultBadge, {
                backgroundColor: isCorrect ? colors.win + "22" : colors.loss + "22",
                borderColor: isCorrect ? colors.win + "60" : colors.loss + "60",
              }]}>
                <Feather name={isCorrect ? "check" : "x"} size={10} color={isCorrect ? colors.win : colors.loss} />
                <Text style={[styles.resultText, { color: isCorrect ? colors.win : colors.loss }]}>
                  {item.score?.fullTime?.home}–{item.score?.fullTime?.away}
                </Text>
              </View>
            )}
            <Text style={[styles.cardTime, { color: colors.mutedForeground }]}>{item.date} · {item.time}</Text>
          </View>
        </View>

        <View style={styles.teamsRow}>
          <TeamLogo crest={item.homeTeam.crest} tla={item.homeTeam.tla} size={28} />
          <Text style={[styles.matchTitle, { color: colors.foreground }]} numberOfLines={1}>
            {item.homeTeam.shortName} — {item.awayTeam.shortName}
          </Text>
          <TeamLogo crest={item.awayTeam.crest} tla={item.awayTeam.tla} size={28} />
        </View>

        <ConfidenceBar confidence={item.prediction.confidence} />

        <View style={styles.riskRow}>
          <RiskBadge level={item.prediction.riskLevel} score={item.prediction.riskScore} size="sm" />
          <Text style={[styles.outcomeText, { color: colors.mutedForeground }]}>
            Прогноз: <Text style={{ color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
              {item.prediction.outcome === "home" ? item.homeTeam.shortName
                : item.prediction.outcome === "away" ? item.awayTeam.shortName
                : "Ничья"}
            </Text>
          </Text>
        </View>

        <View style={[styles.aiBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.aiTag, { color: colors.primary }]}>ИИ:</Text>
          <Text style={[styles.aiText, { color: colors.foreground }]} numberOfLines={2}>
            {item.prediction.aiInsight}
          </Text>
        </View>

        <View style={styles.tipsRow}>
          {item.prediction.tips.slice(0, 3).map((tip, i) => (
            <View key={i} style={[styles.tipCell, {
              backgroundColor: tip.value > 0.10 ? colors.primary + "14" : colors.surface,
              borderColor: tip.value > 0.10 ? colors.primary + "50" : colors.border,
              flex: 1,
            }]}>
              {tip.value > 0.10 && (
                <View style={[styles.valueDot, { backgroundColor: colors.primary }]} />
              )}
              <Text style={[styles.tipCellLabel, { color: colors.foreground }]} numberOfLines={2}>{tip.label}</Text>
              <Text style={[styles.tipCellOdds, { color: tip.value > 0.10 ? colors.primary : colors.foreground }]}>
                {tip.odds.toFixed(2)}
              </Text>
              <Text style={[styles.tipCellConf, { color: colors.mutedForeground }]}>{tip.confidence}%</Text>
            </View>
          ))}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, {
        paddingTop: Platform.OS === "web" ? 67 : insets.top + 12,
        backgroundColor: colors.background, borderBottomColor: colors.border,
      }]}>
        <View style={styles.headerTop}>
          <View>
            <Text style={[styles.title, { color: colors.foreground }]}>ИИ Анализ</Text>
            <Text style={[styles.sub, { color: colors.mutedForeground }]}>
              {isLoading ? "Загружаем..." : `${filtered.length} прогнозов`}
            </Text>
          </View>
          {accuracy && (
            <View style={[styles.accuracyBlock, { backgroundColor: colors.primary + "15", borderColor: colors.primary + "40" }]}>
              <Feather name="target" size={13} color={colors.primary} />
              <View>
                <Text style={[styles.accuracyPct, { color: colors.primary }]}>{accuracy.pct}%</Text>
                <Text style={[styles.accuracyLabel, { color: colors.mutedForeground }]}>точность</Text>
              </View>
              <Text style={[styles.accuracyDetail, { color: colors.mutedForeground }]}>
                {accuracy.correct}/{accuracy.total}
              </Text>
            </View>
          )}
        </View>
      </View>

      <View style={[styles.filtersWrap, { borderBottomColor: colors.border, backgroundColor: colors.background }]}>
        {filters.map((f) => (
          <TouchableOpacity
            key={f.id}
            style={[styles.filterBtn, filter === f.id
              ? { backgroundColor: colors.primary, borderColor: colors.primary }
              : { backgroundColor: "transparent", borderColor: colors.border }]}
            onPress={() => setFilter(f.id)}
          >
            <Feather name={f.icon as any} size={11} color={filter === f.id ? colors.primaryForeground : colors.mutedForeground} />
            <Text style={[styles.filterText, { color: filter === f.id ? colors.primaryForeground : colors.mutedForeground }]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {isLoading ? (
        <View style={styles.list}>
          {[1, 2, 3].map((i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(m) => m.id}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={isFetching && !isLoading} onRefresh={refetch} tintColor={colors.primary} />}
          contentContainerStyle={[styles.list, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
          renderItem={renderCard}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="cpu" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Нет прогнозов</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Попробуйте изменить фильтр</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: 1 },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" },
  title: { fontSize: 24, fontFamily: "Inter_700Bold" },
  sub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  accuracyBlock: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, borderWidth: 1 },
  accuracyPct: { fontSize: 16, fontFamily: "Inter_700Bold" },
  accuracyLabel: { fontSize: 9, fontFamily: "Inter_400Regular" },
  accuracyDetail: { fontSize: 11, fontFamily: "Inter_500Medium" },
  filtersWrap: { flexDirection: "row", paddingHorizontal: 16, paddingVertical: 10, gap: 8, borderBottomWidth: 1 },
  filterBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 11, paddingVertical: 6, borderRadius: 100, borderWidth: 1 },
  filterText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  list: { paddingHorizontal: 16, paddingTop: 12 },
  card: { borderRadius: 16, borderWidth: 1, padding: 14, marginBottom: 12, gap: 10 },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  cardHeaderRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  leagueRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  leagueFlag: { fontSize: 13 },
  cardLeague: { fontSize: 11, fontFamily: "Inter_400Regular" },
  cardTime: { fontSize: 11, fontFamily: "Inter_400Regular" },
  livePill: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 100, borderWidth: 1 },
  liveDot: { width: 5, height: 5, borderRadius: 3 },
  liveText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  resultBadge: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, borderWidth: 1 },
  resultText: { fontSize: 10, fontFamily: "Inter_700Bold" },
  teamsRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  matchTitle: { flex: 1, fontSize: 14, fontFamily: "Inter_700Bold" },
  riskRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  outcomeText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  aiBox: { flexDirection: "row", gap: 6, borderRadius: 10, borderWidth: 1, padding: 10, alignItems: "flex-start" },
  aiTag: { fontSize: 11, fontFamily: "Inter_700Bold", paddingTop: 1 },
  aiText: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
  tipsRow: { flexDirection: "row", gap: 8 },
  tipCell: { borderRadius: 10, borderWidth: 1, padding: 10, gap: 3 },
  valueDot: { width: 6, height: 6, borderRadius: 3 },
  tipCellLabel: { fontSize: 10, fontFamily: "Inter_500Medium", lineHeight: 13 },
  tipCellOdds: { fontSize: 17, fontFamily: "Inter_700Bold" },
  tipCellConf: { fontSize: 10, fontFamily: "Inter_400Regular" },
  empty: { alignItems: "center", paddingTop: 80, gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular" },
});
