import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useMemo, useState } from "react";
import {
  Alert,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useApp, type PredictionHistoryItem } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

type HistoryFilter = "all" | "won" | "lost" | "pending";

function StatCard({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  const colors = useColors();
  return (
    <View style={[statStyles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[statStyles.label, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[statStyles.value, { color: color ?? colors.foreground }]}>{value}</Text>
      {sub && <Text style={[statStyles.sub, { color: colors.mutedForeground }]}>{sub}</Text>}
    </View>
  );
}

const statStyles = StyleSheet.create({
  card: { flex: 1, borderRadius: 14, borderWidth: 1, padding: 12, gap: 2, alignItems: "center" },
  label: { fontSize: 10, fontFamily: "Inter_500Medium", textAlign: "center" },
  value: { fontSize: 20, fontFamily: "Inter_700Bold" },
  sub: { fontSize: 10, fontFamily: "Inter_400Regular" },
});

function HistoryItem({ item, onUpdateOutcome }: { item: PredictionHistoryItem; onUpdateOutcome: (id: string, outcome: "won" | "lost") => void }) {
  const colors = useColors();
  const outcomeColor =
    item.outcome === "won" ? colors.win
    : item.outcome === "lost" ? colors.loss
    : colors.draw;
  const outcomeLabel = item.outcome === "won" ? "Выиграно" : item.outcome === "lost" ? "Проиграно" : "Ожидание";
  const profitSign = item.profit >= 0 ? "+" : "";

  return (
    <View style={[hStyles.row, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[hStyles.outcomeStripe, { backgroundColor: outcomeColor }]} />
      <View style={hStyles.body}>
        <View style={hStyles.top}>
          <View style={hStyles.topLeft}>
            <Text style={[hStyles.league, { color: colors.mutedForeground }]}>
              {item.leagueFlag} {item.league} · {item.date}
            </Text>
            <Text style={[hStyles.matchTitle, { color: colors.foreground }]} numberOfLines={1}>{item.matchTitle}</Text>
          </View>
          <View style={[hStyles.outcomePill, { backgroundColor: outcomeColor + "22", borderColor: outcomeColor + "60" }]}>
            <Text style={[hStyles.outcomeText, { color: outcomeColor }]}>{outcomeLabel}</Text>
          </View>
        </View>
        <View style={hStyles.betRow}>
          <Text style={[hStyles.betLabel, { color: colors.foreground }]} numberOfLines={1}>{item.betLabel}</Text>
          <View style={[hStyles.oddsChip, { backgroundColor: colors.surface }]}>
            <Text style={[hStyles.oddsChipText, { color: colors.foreground }]}>{item.odds.toFixed(2)}</Text>
          </View>
        </View>
        <View style={hStyles.bottom}>
          <Text style={[hStyles.stake, { color: colors.mutedForeground }]}>Ставка: {item.stake}₽</Text>
          <Text style={[hStyles.profit, { color: item.profit >= 0 ? colors.win : colors.loss }]}>
            {profitSign}{item.profit}₽
          </Text>
          {item.outcome === "pending" && (
            <View style={hStyles.actionRow}>
              <TouchableOpacity
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  onUpdateOutcome(item.id, "won");
                }}
                style={[hStyles.actionBtn, { backgroundColor: colors.win + "22", borderColor: colors.win + "60" }]}
              >
                <Feather name="check" size={12} color={colors.win} />
                <Text style={[hStyles.actionText, { color: colors.win }]}>Выиграл</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  onUpdateOutcome(item.id, "lost");
                }}
                style={[hStyles.actionBtn, { backgroundColor: colors.loss + "22", borderColor: colors.loss + "60" }]}
              >
                <Feather name="x" size={12} color={colors.loss} />
                <Text style={[hStyles.actionText, { color: colors.loss }]}>Проиграл</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

const hStyles = StyleSheet.create({
  row: { flexDirection: "row", borderRadius: 14, borderWidth: 1, overflow: "hidden", marginBottom: 10 },
  outcomeStripe: { width: 4 },
  body: { flex: 1, padding: 12, gap: 8 },
  top: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  topLeft: { flex: 1, gap: 2, marginRight: 8 },
  league: { fontSize: 10, fontFamily: "Inter_400Regular" },
  matchTitle: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  outcomePill: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100, borderWidth: 1 },
  outcomeText: { fontSize: 10, fontFamily: "Inter_700Bold" },
  betRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  betLabel: { flex: 1, fontSize: 12, fontFamily: "Inter_500Medium" },
  oddsChip: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  oddsChipText: { fontSize: 14, fontFamily: "Inter_700Bold" },
  bottom: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  stake: { fontSize: 11, fontFamily: "Inter_400Regular" },
  profit: { fontSize: 15, fontFamily: "Inter_700Bold" },
  actionRow: { flexDirection: "row", gap: 6, marginLeft: "auto" as any },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 100, borderWidth: 1 },
  actionText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
});

export default function HistoryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { history, userStats, updateOutcome, clearHistory, trackedOdds, removeTracked } = useApp();
  const [filter, setFilter] = useState<HistoryFilter>("all");
  const [tab, setTab] = useState<"history" | "tracked">("history");

  const filtered = useMemo(() => {
    return history.filter((h) => {
      if (filter === "all") return true;
      return h.outcome === filter;
    });
  }, [history, filter]);

  const handleClear = () => {
    Alert.alert("Очистить историю?", "Это действие нельзя отменить.", [
      { text: "Отмена", style: "cancel" },
      { text: "Очистить", style: "destructive", onPress: clearHistory },
    ]);
  };

  const handleUpdateOutcome = (id: string, outcome: "won" | "lost") => {
    const item = history.find((h) => h.id === id);
    if (!item) return;
    const profit = outcome === "won" ? (item.odds - 1) * item.stake : -item.stake;
    updateOutcome(id, outcome, profit);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, {
        paddingTop: Platform.OS === "web" ? 67 : insets.top + 12,
        backgroundColor: colors.background, borderBottomColor: colors.border,
      }]}>
        <View style={styles.headerRow}>
          <Text style={[styles.title, { color: colors.foreground }]}>История</Text>
          {history.length > 0 && (
            <TouchableOpacity onPress={handleClear} style={[styles.clearBtn, { borderColor: colors.border }]}>
              <Feather name="trash-2" size={13} color={colors.mutedForeground} />
              <Text style={[styles.clearText, { color: colors.mutedForeground }]}>Очистить</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.statsGrid}>
          <StatCard
            label="Win Rate"
            value={`${userStats.winRate.toFixed(0)}%`}
            sub={`${userStats.wonBets}/${userStats.totalBets}`}
            color={userStats.winRate >= 55 ? colors.win : userStats.winRate >= 45 ? colors.draw : colors.loss}
          />
          <StatCard
            label="ROI"
            value={`${userStats.roi >= 0 ? "+" : ""}${userStats.roi.toFixed(1)}%`}
            color={userStats.roi >= 0 ? colors.win : colors.loss}
          />
          <StatCard
            label="Прибыль"
            value={`${userStats.totalProfit >= 0 ? "+" : ""}${userStats.totalProfit}₽`}
            color={userStats.totalProfit >= 0 ? colors.win : colors.loss}
          />
          <StatCard
            label="Ставок"
            value={`${userStats.totalBets}`}
            sub={`${userStats.pendingBets} в ожидании`}
          />
        </View>

        <View style={styles.tabRow}>
          {([{ id: "history", label: "Ставки" }, { id: "tracked", label: "Отслеживание" }] as const).map((t) => (
            <TouchableOpacity
              key={t.id}
              style={[styles.tabBtn, tab === t.id
                ? { borderBottomColor: colors.primary }
                : { borderBottomColor: "transparent" }]}
              onPress={() => setTab(t.id)}
            >
              <Text style={[styles.tabText, { color: tab === t.id ? colors.primary : colors.mutedForeground }]}>
                {t.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {tab === "history" ? (
        <>
          <View style={[styles.filtersWrap, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
            {([
              { id: "all" as const, label: "Все" },
              { id: "won" as const, label: "Выиграно" },
              { id: "lost" as const, label: "Проиграно" },
              { id: "pending" as const, label: "Ожидание" },
            ]).map((f) => (
              <TouchableOpacity
                key={f.id}
                style={[styles.filterBtn, filter === f.id
                  ? { backgroundColor: colors.primary, borderColor: colors.primary }
                  : { backgroundColor: "transparent", borderColor: colors.border }]}
                onPress={() => setFilter(f.id)}
              >
                <Text style={[styles.filterText, { color: filter === f.id ? colors.primaryForeground : colors.mutedForeground }]}>
                  {f.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <FlatList
            data={filtered}
            keyExtractor={(h) => h.id}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={[styles.list, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
            renderItem={({ item }) => <HistoryItem item={item} onUpdateOutcome={handleUpdateOutcome} />}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Feather name="clock" size={40} color={colors.mutedForeground} />
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>История пуста</Text>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  Добавляйте ставки из карточки матча
                </Text>
              </View>
            }
          />
        </>
      ) : (
        <FlatList
          data={trackedOdds}
          keyExtractor={(t) => `${t.matchId}-${t.betLabel}`}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.list, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
          renderItem={({ item }) => (
            <View style={[styles.trackedRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.trackedLeft}>
                <Text style={[styles.trackedMatch, { color: colors.foreground }]} numberOfLines={1}>{item.matchTitle}</Text>
                <Text style={[styles.trackedLabel, { color: colors.mutedForeground }]} numberOfLines={1}>{item.betLabel}</Text>
              </View>
              <View style={styles.trackedRight}>
                <Text style={[styles.trackedOdds, { color: colors.primary }]}>{item.currentOdds.toFixed(2)}</Text>
                <TouchableOpacity onPress={() => removeTracked(item.matchId, item.betLabel)} hitSlop={8}>
                  <Feather name="x" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="bell" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Нет отслеживаемых</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Нажмите "Следить" в сравнении букмекеров
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 0, borderBottomWidth: 1 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingBottom: 12 },
  title: { fontSize: 24, fontFamily: "Inter_700Bold" },
  clearBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, borderWidth: 1 },
  clearText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  statsGrid: { flexDirection: "row", gap: 8, marginBottom: 12 },
  tabRow: { flexDirection: "row", gap: 0 },
  tabBtn: { flex: 1, alignItems: "center", paddingVertical: 10, borderBottomWidth: 2 },
  tabText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  filtersWrap: { flexDirection: "row", paddingHorizontal: 16, paddingVertical: 10, gap: 8, borderBottomWidth: 1 },
  filterBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 100, borderWidth: 1 },
  filterText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  list: { paddingHorizontal: 16, paddingTop: 12 },
  empty: { alignItems: "center", paddingTop: 80, gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", paddingHorizontal: 20 },
  trackedRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 14, borderWidth: 1, padding: 14, marginBottom: 10 },
  trackedLeft: { flex: 1, gap: 3, marginRight: 12 },
  trackedMatch: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  trackedLabel: { fontSize: 12, fontFamily: "Inter_400Regular" },
  trackedRight: { flexDirection: "row", alignItems: "center", gap: 12 },
  trackedOdds: { fontSize: 20, fontFamily: "Inter_700Bold" },
});
