import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  RefreshControl,
  SectionList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { MatchCard } from "@/components/MatchCard";
import { SkeletonCard } from "@/components/SkeletonCard";
import { TeamLogo } from "@/components/TeamLogo";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { useMatches, type LiveMatch } from "@/hooks/useMatches";

const LEAGUES = [
  { code: "all", flag: "🌍", label: "Все" },
  { code: "PL", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", label: "АПЛ" },
  { code: "PD", flag: "🇪🇸", label: "Ла Лига" },
  { code: "BL1", flag: "🇩🇪", label: "Бундеслига" },
  { code: "FL1", flag: "🇫🇷", label: "Лига 1" },
  { code: "SA", flag: "🇮🇹", label: "Серия А" },
  { code: "DED", flag: "🇳🇱", label: "Эредивизи" },
];

export default function MatchesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data: matches, isLoading, refetch, isFetching } = useMatches();
  const { unreadCount, toggleTheme } = useApp();
  const [search, setSearch] = useState("");
  const [activeLeague, setActiveLeague] = useState("all");

  const liveCount = useMemo(() => (matches ?? []).filter((m) => m.status === "live").length, [matches]);

  const topPick = useMemo(() =>
    (matches ?? []).reduce<LiveMatch | null>((best, m) => {
      if (m.status === "finished") return best;
      if (!best || m.prediction.confidence > best.prediction.confidence) return m;
      return best;
    }, null),
    [matches]
  );

  const filtered = useMemo(() => {
    if (!matches) return [];
    return matches.filter((m) => {
      const q = search.toLowerCase().trim();
      const matchesSearch = !q
        || m.homeTeam.name.toLowerCase().includes(q)
        || m.awayTeam.name.toLowerCase().includes(q)
        || m.league.toLowerCase().includes(q);
      const matchesLeague = activeLeague === "all" || m.leagueCode === activeLeague;
      return matchesSearch && matchesLeague;
    });
  }, [matches, search, activeLeague]);

  const sections = useMemo(() => {
    const groups: Record<string, LiveMatch[]> = {};
    for (const m of filtered) {
      const key = m.status === "live" ? "🔴 Сейчас" : m.status === "finished" ? "✅ Завершены" : `📅 ${m.date}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(m);
    }
    const order = (k: string) => k.startsWith("🔴") ? 0 : k.startsWith("📅") ? 1 : 2;
    return Object.entries(groups)
      .sort(([a], [b]) => order(a) - order(b))
      .map(([title, data]) => ({ title, data }));
  }, [filtered]);

  const ListHeader = (
    <>
      {topPick && !search && activeLeague === "all" && (
        <TouchableOpacity
          activeOpacity={0.88}
          onPress={() => router.push(`/match/${topPick.id}`)}
          style={[styles.topPick, { borderColor: colors.primary + "60" }]}
        >
          <LinearGradient
            colors={[colors.primary + "30", colors.primary + "08"]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.topPickContent}>
            <View style={styles.topPickHeader}>
              <View style={[styles.topPickBadge, { backgroundColor: colors.primary }]}>
                <Feather name="zap" size={10} color={colors.primaryForeground} />
                <Text style={[styles.topPickBadgeText, { color: colors.primaryForeground }]}>ТОП ПРОГНОЗ</Text>
              </View>
              <Text style={[styles.topPickConf, { color: colors.primary }]}>{topPick.prediction.confidence}%</Text>
            </View>
            <View style={styles.topPickTeams}>
              <TeamLogo crest={topPick.homeTeam.crest} tla={topPick.homeTeam.tla} size={36} />
              <View style={styles.topPickCentre}>
                <Text style={[styles.topPickMatchName, { color: colors.foreground }]} numberOfLines={1}>
                  {topPick.homeTeam.shortName} — {topPick.awayTeam.shortName}
                </Text>
                <Text style={[styles.topPickLeague, { color: colors.mutedForeground }]}>
                  {topPick.leagueFlag} {topPick.league} · {topPick.time}
                </Text>
                <Text style={[styles.topPickBet, { color: colors.primary }]}>
                  {topPick.prediction.tips[0]?.label ?? topPick.prediction.valueOutcome} @ {topPick.prediction.tips[0]?.odds.toFixed(2) ?? "–"}
                </Text>
              </View>
              <TeamLogo crest={topPick.awayTeam.crest} tla={topPick.awayTeam.tla} size={36} />
            </View>
          </View>
        </TouchableOpacity>
      )}
    </>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, {
        paddingTop: Platform.OS === "web" ? 67 : insets.top + 12,
        backgroundColor: colors.background, borderBottomColor: colors.border,
      }]}>
        <View style={styles.headerTop}>
          <View style={styles.brandRow}>
            <View style={[styles.logoBox, { backgroundColor: colors.primary + "22" }]}>
              <Feather name="activity" size={18} color={colors.primary} />
            </View>
            <View>
              <Text style={[styles.appName, { color: colors.foreground }]}>BetAnalytics</Text>
              {liveCount > 0 && (
                <View style={styles.liveRow}>
                  <View style={[styles.liveDot, { backgroundColor: colors.loss }]} />
                  <Text style={[styles.liveCount, { color: colors.loss }]}>{liveCount} матч{liveCount === 1 ? "" : "а"} сейчас</Text>
                </View>
              )}
            </View>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.push("/notifications" as any);
              }}
              style={[styles.iconBtn, { backgroundColor: colors.surface }]}
              hitSlop={6}
            >
              <Feather name="bell" size={18} color={colors.foreground} />
              {unreadCount > 0 && (
                <View style={[styles.notifBadge, { backgroundColor: colors.loss }]}>
                  <Text style={styles.notifCount}>{unreadCount > 9 ? "9+" : unreadCount}</Text>
                </View>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              onPress={toggleTheme}
              style={[styles.iconBtn, { backgroundColor: colors.surface }]}
              hitSlop={6}
            >
              <Feather name="moon" size={18} color={colors.foreground} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={[styles.searchRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Feather name="search" size={15} color={colors.mutedForeground} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="Поиск команды, лиги..."
            placeholderTextColor={colors.mutedForeground}
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
            clearButtonMode="while-editing"
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch("")} hitSlop={8}>
              <Feather name="x" size={14} color={colors.mutedForeground} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={[styles.leagueWrap, { borderBottomColor: colors.border }]}>
        <FlatList
          horizontal
          data={LEAGUES}
          keyExtractor={(l) => l.code}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.leagueScroll}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.leagueChip, activeLeague === item.code
                ? { backgroundColor: colors.primary + "22", borderColor: colors.primary }
                : { backgroundColor: colors.surface, borderColor: colors.border }]}
              onPress={() => {
                Haptics.selectionAsync();
                setActiveLeague(item.code);
              }}
            >
              <Text style={styles.leagueFlag}>{item.flag}</Text>
              <Text style={[styles.leagueLabel, { color: activeLeague === item.code ? colors.primary : colors.mutedForeground }]}>
                {item.label}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {isLoading ? (
        <View style={styles.list}>
          {[1, 2, 3].map((i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          stickySectionHeadersEnabled={false}
          refreshControl={
            <RefreshControl
              refreshing={isFetching && !isLoading}
              onRefresh={refetch}
              tintColor={colors.primary}
            />
          }
          contentContainerStyle={[styles.list, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 90 }]}
          ListHeaderComponent={ListHeader}
          renderSectionHeader={({ section }) => (
            <Text style={[styles.sectionHeader, { color: colors.mutedForeground, borderBottomColor: colors.border }]}>
              {section.title}
            </Text>
          )}
          renderItem={({ item, index }) => <MatchCard match={item} index={index} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="search" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Матчей не найдено</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Попробуйте изменить фильтры
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 10, borderBottomWidth: 1, gap: 10 },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  logoBox: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  appName: { fontSize: 20, fontFamily: "Inter_700Bold" },
  liveRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  liveDot: { width: 5, height: 5, borderRadius: 3 },
  liveCount: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
  headerActions: { flexDirection: "row", gap: 8 },
  iconBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  notifBadge: { position: "absolute", top: 4, right: 4, minWidth: 14, height: 14, borderRadius: 7, alignItems: "center", justifyContent: "center", paddingHorizontal: 2 },
  notifCount: { fontSize: 9, fontFamily: "Inter_700Bold", color: "#FFF" },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 9 },
  searchInput: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular", padding: 0 },
  leagueWrap: { borderBottomWidth: 1 },
  leagueScroll: { paddingHorizontal: 16, paddingVertical: 10, gap: 8 },
  leagueChip: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 100, borderWidth: 1 },
  leagueFlag: { fontSize: 13 },
  leagueLabel: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  list: { paddingHorizontal: 16, paddingTop: 12 },
  topPick: { borderRadius: 18, borderWidth: 1.5, marginBottom: 16, overflow: "hidden" },
  topPickContent: { padding: 14, gap: 10 },
  topPickHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  topPickBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 100 },
  topPickBadgeText: { fontSize: 10, fontFamily: "Inter_700Bold" },
  topPickConf: { fontSize: 22, fontFamily: "Inter_700Bold" },
  topPickTeams: { flexDirection: "row", alignItems: "center", gap: 10 },
  topPickCentre: { flex: 1, gap: 3 },
  topPickMatchName: { fontSize: 14, fontFamily: "Inter_700Bold" },
  topPickLeague: { fontSize: 11, fontFamily: "Inter_400Regular" },
  topPickBet: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  sectionHeader: { fontSize: 12, fontFamily: "Inter_600SemiBold", marginBottom: 8, marginTop: 4, paddingBottom: 6, borderBottomWidth: 1 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center" },
});
