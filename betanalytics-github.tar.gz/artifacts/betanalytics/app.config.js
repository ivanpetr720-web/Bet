const isReplit = Boolean(process.env.REPL_ID);

module.exports = {
  expo: {
    name: "BetAnalytics",
    slug: "betanalytics",
    version: "1.0.0",
    orientation: "portrait",
    icon: "./assets/images/icon.png",
    scheme: "betanalytics",
    userInterfaceStyle: "dark",
    newArchEnabled: true,
    splash: {
      image: "./assets/images/icon.png",
      resizeMode: "contain",
      backgroundColor: "#080C14",
    },
    ios: {
      supportsTablet: false,
      bundleIdentifier: "com.betanalytics.app",
    },
    android: {
      package: "com.betanalytics.app",
      adaptiveIcon: {
        foregroundImage: "./assets/images/icon.png",
        backgroundColor: "#080C14",
      },
      permissions: ["RECEIVE_BOOT_COMPLETED", "VIBRATE"],
    },
    web: {
      favicon: "./assets/images/icon.png",
      output: "static",
    },
    plugins: [
      isReplit
        ? ["expo-router", { origin: "https://replit.com/" }]
        : "expo-router",
      "expo-font",
      "expo-web-browser",
    ],
    experiments: {
      typedRoutes: true,
      reactCompiler: true,
    },
  },
};
