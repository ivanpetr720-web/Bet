import React, { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming } from "react-native-reanimated";
import { useColors } from "@/hooks/useColors";

function SkeletonBox({ width, height, borderRadius = 8 }: {
  width: number | string; height: number; borderRadius?: number;
}) {
  const colors = useColors();
  const opacity = useSharedValue(1);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(0.3, { duration: 900 }), -1, true);
  }, []);

  const style = useAnimatedStyle(() => ({ opacity: opacity.value }));

  return (
    <Animated.View
      style={[{ width: width as number, height, borderRadius, backgroundColor: colors.surfaceBorder }, style]}
    />
  );
}

export function SkeletonCard() {
  const colors = useColors();
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.header}>
        <SkeletonBox width={100} height={11} borderRadius={5} />
        <SkeletonBox width={70} height={11} borderRadius={5} />
      </View>
      <View style={styles.teams}>
        <View style={styles.teamSide}>
          <SkeletonBox width={44} height={44} borderRadius={8} />
          <SkeletonBox width={72} height={12} borderRadius={5} />
        </View>
        <SkeletonBox width={52} height={34} borderRadius={10} />
        <View style={[styles.teamSide, styles.teamRight]}>
          <SkeletonBox width={44} height={44} borderRadius={8} />
          <SkeletonBox width={72} height={12} borderRadius={5} />
        </View>
      </View>
      <SkeletonBox width="100%" height={4} borderRadius={4} />
      <View style={styles.tipRow}>
        <SkeletonBox width={120} height={34} borderRadius={10} />
        <SkeletonBox width={90} height={34} borderRadius={10} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 18, borderWidth: 1, padding: 16, marginBottom: 12, gap: 14 },
  header: { flexDirection: "row", justifyContent: "space-between" },
  teams: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  teamSide: { flex: 1, gap: 8, alignItems: "flex-start" },
  teamRight: { alignItems: "flex-end" },
  tipRow: { flexDirection: "row", justifyContent: "space-between" },
});
