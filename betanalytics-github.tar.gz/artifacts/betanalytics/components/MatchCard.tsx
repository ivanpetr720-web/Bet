import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useEffect } from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withDelay, withTiming } from "react-native-reanimated";
import { useApp } from "@/context/AppContext";
import type { LiveMatch } from "@/hooks/useMatches";
import { useColors } from "@/hooks/useColors";
import { ConfidenceBar } from "./ConfidenceBar";
import { FormBadges } from "./FormBadges";
import { RiskBadge } from "./RiskBadge";
import { TeamLogo } from "./TeamLogo";

interface Props {
  match: LiveMatch;
  index?: number;
}

export function MatchCard({ match, index = 0 }: Props) {
  const colors = useColors();
  const { isFavorite, toggleFavorite } = useApp();
  const fav = isFavorite(match.id);
  const bestTip = match.prediction.tips[0];

  const opacity = useSharedValue(0);
  const translateY = useSharedValue(24);

  useEffect(() => {
    const delay = Math.min(index * 60, 360);
    opacity.value = withDelay(delay, withTiming(1, { duration: 380 }));
    translateY.value = withDelay(delay, withTiming(0, { duration: 380 }));
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translateY.value }],
  }));

  const confColor =
    match.prediction.confidence >= 70 ? colors.win
    : match.prediction.confidence >= 55 ? colors.draw
    : colors.loss;

  const outcomeLabel =
    match.prediction.outcome === "home" ? match.homeTeam.shortName
    : match.prediction.outcome === "away" ? match.awayTeam.shortName
    : "Ничья";

  const isFinished = match.status === "finished";
  const isLive = match.status === "live";
  const actualOutcome = isFinished && match.score?.fullTime
    ? (match.score.fullTime.home! > match.score.fullTime.away! ? "home"
      : match.score.fullTime.home! < match.score.fullTime.away! ? "away" : "draw")
    : null;
  const isCorrect = actualOutcome === match.prediction.outcome;

  return (
    <Animated.View style={animStyle}>
      <TouchableOpacity
        activeOpacity={0.88}
        style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}
        onPress={() => router.push(`/match/${match.id}`)}
      >
        <LinearGradient
          colors={[confColor + "CC", confColor + "00"]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={styles.topLine}
        />

        <View style={styles.header}>
          <View style={styles.leagueRow}>
            <Text style={styles.leagueFlag}>{match.leagueFlag}</Text>
            <Text style={[styles.leagueName, { color: colors.mutedForeground }]}>{match.league}</Text>
            {isLive && (
              <View style={[styles.livePill, { backgroundColor: colors.loss + "22", borderColor: colors.loss }]}>
                <View style={[styles.liveDot, { backgroundColor: colors.loss }]} />
                <Text style={[styles.liveText, { color: colors.loss }]}>LIVE</Text>
              </View>
            )}
            {isFinished && (
              <View style={[styles.livePill, {
                backgroundColor: isCorrect ? colors.win + "22" : colors.loss + "22",
                borderColor: isCorrect ? colors.win : colors.loss,
              }]}>
                <Feather name={isCorrect ? "check" : "x"} size={9} color={isCorrect ? colors.win : colors.loss} />
                <Text style={[styles.liveText, { color: isCorrect ? colors.win : colors.loss }]}>
                  {isCorrect ? "ВЕРНО" : "МИМО"}
                </Text>
              </View>
            )}
          </View>
          <View style={styles.headerRight}>
            <RiskBadge level={match.prediction.riskLevel} size="sm" />
            <Text style={[styles.matchTime, { color: colors.mutedForeground }]}>{match.time}</Text>
            <TouchableOpacity onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              toggleFavorite(match.id);
            }} hitSlop={10}>
              <Feather name="bookmark" size={15} color={fav ? colors.primary : colors.mutedForeground} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.teamsRow}>
          <View style={styles.teamSide}>
            <TeamLogo crest={match.homeTeam.crest} tla={match.homeTeam.tla} size={44} />
            <Text style={[styles.teamName, { color: colors.foreground }]} numberOfLines={2}>
              {match.homeTeam.shortName}
            </Text>
            {match.homeTeam.position && (
              <Text style={[styles.pos, { color: colors.mutedForeground }]}>#{match.homeTeam.position}</Text>
            )}
            <FormBadges form={match.homeTeam.form} size="sm" />
          </View>

          <View style={styles.centre}>
            {isLive && match.score?.fullTime?.home != null ? (
              <View style={[styles.scoreBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <Text style={[styles.scoreText, { color: colors.foreground }]}>
                  {match.score.fullTime.home}:{match.score.fullTime.away}
                </Text>
                <View style={[styles.liveDot, { backgroundColor: colors.loss, alignSelf: "center" }]} />
              </View>
            ) : isFinished && match.score?.fullTime?.home != null ? (
              <View style={[styles.scoreBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <Text style={[styles.scoreText, { color: colors.foreground }]}>
                  {match.score.fullTime.home}:{match.score.fullTime.away}
                </Text>
                <Text style={[styles.finishedLabel, { color: colors.mutedForeground }]}>ФТ</Text>
              </View>
            ) : (
              <View style={[styles.predBox, { backgroundColor: colors.surface, borderColor: colors.primary + "55" }]}>
                <Text style={[styles.predScore, { color: colors.primary }]}>{match.prediction.scoreline}</Text>
                <Text style={[styles.predLabel, { color: colors.mutedForeground }]}>прогноз</Text>
              </View>
            )}
          </View>

          <View style={[styles.teamSide, styles.teamRight]}>
            <TeamLogo crest={match.awayTeam.crest} tla={match.awayTeam.tla} size={44} />
            <Text style={[styles.teamName, { color: colors.foreground }]} numberOfLines={2}>
              {match.awayTeam.shortName}
            </Text>
            {match.awayTeam.position && (
              <Text style={[styles.pos, { color: colors.mutedForeground }]}>#{match.awayTeam.position}</Text>
            )}
            <FormBadges form={match.awayTeam.form} size="sm" />
          </View>
        </View>

        <View style={styles.confRow}>
          <Text style={[styles.outcomeLabel, { color: colors.mutedForeground }]}>
            Исход: <Text style={[styles.outcomeName, { color: colors.foreground }]}>{outcomeLabel}</Text>
          </Text>
          <Text style={[styles.confPct, { color: confColor }]}>{match.prediction.confidence}%</Text>
        </View>
        <ConfidenceBar confidence={match.prediction.confidence} showLabel={false} height={4} />

        {bestTip && (
          <View style={[styles.tipBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.tipLeft}>
              {bestTip.value > 0.08 && (
                <View style={[styles.valuePill, { backgroundColor: colors.primary + "22" }]}>
                  <Text style={[styles.valuePillText, { color: colors.primary }]}>
                    VALUE +{(bestTip.value * 100).toFixed(0)}%
                  </Text>
                </View>
              )}
              <Text style={[styles.tipLabel, { color: colors.foreground }]} numberOfLines={1}>
                {bestTip.label}
              </Text>
            </View>
            <Text style={[styles.tipOdds, { color: colors.primary }]}>{bestTip.odds.toFixed(2)}</Text>
          </View>
        )}

        {match.odds.length > 0 && (
          <View style={styles.oddsRow}>
            {(["home", "draw", "away"] as const).map((k) => {
              const best = Math.max(...match.odds.map((o) => o[k] ?? 0).filter(Boolean));
              const labels = { home: "П1", draw: "Х", away: "П2" };
              if (!best) return null;
              return (
                <View key={k} style={[styles.oddsChip, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={[styles.oddsChipLabel, { color: colors.mutedForeground }]}>{labels[k]}</Text>
                  <Text style={[styles.oddsChipVal, { color: colors.foreground }]}>{best.toFixed(2)}</Text>
                </View>
              );
            })}
            <Text style={[styles.bkCount, { color: colors.mutedForeground }]}>{match.odds.length} букм.</Text>
          </View>
        )}
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 18, borderWidth: 1, marginBottom: 12, overflow: "hidden", paddingHorizontal: 16, paddingBottom: 14, paddingTop: 0, gap: 10 },
  topLine: { height: 3, marginHorizontal: -16, marginBottom: 4 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  leagueRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  leagueFlag: { fontSize: 13 },
  leagueName: { fontSize: 11, fontFamily: "Inter_500Medium" },
  livePill: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 100, borderWidth: 1, marginLeft: 4 },
  liveDot: { width: 5, height: 5, borderRadius: 3 },
  liveText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  matchTime: { fontSize: 11, fontFamily: "Inter_400Regular" },
  teamsRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  teamSide: { flex: 1, alignItems: "flex-start", gap: 5 },
  teamRight: { alignItems: "flex-end" },
  teamName: { fontSize: 13, fontFamily: "Inter_600SemiBold", lineHeight: 18 },
  pos: { fontSize: 10, fontFamily: "Inter_400Regular" },
  centre: { alignItems: "center", paddingHorizontal: 8 },
  scoreBox: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 8, alignItems: "center", gap: 3 },
  scoreText: { fontSize: 22, fontFamily: "Inter_700Bold" },
  finishedLabel: { fontSize: 9, fontFamily: "Inter_500Medium" },
  predBox: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 8, alignItems: "center" },
  predScore: { fontSize: 22, fontFamily: "Inter_700Bold" },
  predLabel: { fontSize: 9, fontFamily: "Inter_400Regular" },
  confRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  outcomeLabel: { fontSize: 12, fontFamily: "Inter_400Regular" },
  outcomeName: { fontFamily: "Inter_600SemiBold" },
  confPct: { fontSize: 13, fontFamily: "Inter_700Bold" },
  tipBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 8 },
  tipLeft: { flex: 1, gap: 3 },
  valuePill: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 100 },
  valuePillText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  tipLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  tipOdds: { fontSize: 20, fontFamily: "Inter_700Bold" },
  oddsRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  oddsChip: { borderRadius: 8, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 5, alignItems: "center", gap: 1 },
  oddsChipLabel: { fontSize: 9, fontFamily: "Inter_500Medium" },
  oddsChipVal: { fontSize: 13, fontFamily: "Inter_700Bold" },
  bkCount: { fontSize: 10, fontFamily: "Inter_400Regular", marginLeft: "auto" as any },
});
