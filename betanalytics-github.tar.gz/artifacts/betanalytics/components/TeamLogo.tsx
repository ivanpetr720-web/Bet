import { Image } from "expo-image";
import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

interface Props {
  crest: string;
  tla: string;
  size?: number;
}

export function TeamLogo({ crest, tla, size = 44 }: Props) {
  const colors = useColors();
  const [error, setError] = React.useState(false);

  if (error || !crest) {
    return (
      <View
        style={[
          styles.fallback,
          { width: size, height: size, borderRadius: size / 4, backgroundColor: colors.surface, borderColor: colors.border },
        ]}
      >
        <Text style={[styles.tla, { fontSize: size * 0.3, color: colors.mutedForeground }]}>
          {tla.slice(0, 3)}
        </Text>
      </View>
    );
  }

  return (
    <Image
      source={{ uri: crest }}
      style={{ width: size, height: size, borderRadius: size / 8 }}
      contentFit="contain"
      onError={() => setError(true)}
      transition={200}
    />
  );
}

const styles = StyleSheet.create({
  fallback: { alignItems: "center", justifyContent: "center", borderWidth: 1 },
  tla: { fontFamily: "Inter_700Bold" },
});
