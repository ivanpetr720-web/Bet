import React, { useEffect } from "react";
import { StyleSheet, Text, View } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from "react-native-reanimated";
import { useColors } from "@/hooks/useColors";

interface Props {
  confidence: number;
  showLabel?: boolean;
  height?: number;
}

export function ConfidenceBar({ confidence, showLabel = true, height = 6 }: Props) {
  const colors = useColors();
  const width = useSharedValue(0);

  useEffect(() => {
    width.value = withTiming(confidence, { duration: 900 });
  }, [confidence]);

  const animatedStyle = useAnimatedStyle(() => ({
    width: `${width.value}%`,
  }));

  const getColor = () => {
    if (confidence >= 70) return colors.win;
    if (confidence >= 55) return colors.draw;
    return colors.loss;
  };

  const getLabel = () => {
    if (confidence >= 70) return "Высокая";
    if (confidence >= 55) return "Средняя";
    return "Низкая";
  };

  const c = getColor();

  return (
    <View>
      {showLabel && (
        <View style={styles.labelRow}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            {getLabel()} уверенность
          </Text>
          <Text style={[styles.value, { color: c }]}>{confidence}%</Text>
        </View>
      )}
      <View style={[styles.track, { height, backgroundColor: colors.surface }]}>
        <Animated.View style={[styles.fill, animatedStyle, { height, backgroundColor: c }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  labelRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 6 },
  label: { fontSize: 12, fontFamily: "Inter_400Regular" },
  value: { fontSize: 12, fontFamily: "Inter_700Bold" },
  track: { borderRadius: 100, overflow: "hidden" },
  fill: { borderRadius: 100 },
});
