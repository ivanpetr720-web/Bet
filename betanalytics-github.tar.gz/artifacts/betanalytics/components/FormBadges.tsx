import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

interface Props {
  form: ("W" | "D" | "L")[];
  size?: "sm" | "md";
  showLabel?: boolean;
}

export function FormBadges({ form, size = "md", showLabel = false }: Props) {
  const colors = useColors();
  const dim = size === "sm" ? 20 : 26;
  const fontSize = size === "sm" ? 9 : 11;

  return (
    <View>
      {showLabel && (
        <Text style={[styles.label, { color: colors.mutedForeground }]}>Форма</Text>
      )}
      <View style={styles.row}>
        {form.map((result, i) => {
          const bg = result === "W" ? colors.win : result === "D" ? colors.draw : colors.loss;
          return (
            <View
              key={i}
              style={[
                styles.badge,
                { width: dim, height: dim, borderRadius: dim / 2, backgroundColor: bg + "22", borderColor: bg },
              ]}
            >
              <Text style={[styles.text, { color: bg, fontSize }]}>{result}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  label: { fontSize: 11, fontFamily: "Inter_500Medium", marginBottom: 5 },
  row: { flexDirection: "row", gap: 4 },
  badge: { alignItems: "center", justifyContent: "center", borderWidth: 1 },
  text: { fontFamily: "Inter_700Bold" },
});
