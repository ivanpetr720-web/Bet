import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

interface Props {
  level: "low" | "medium" | "high";
  score?: number;
  size?: "sm" | "md";
}

const RISK_CONFIG = {
  low: { label: "Низкий риск", icon: "shield" as const },
  medium: { label: "Средний риск", icon: "alert-circle" as const },
  high: { label: "Высокий риск", icon: "alert-triangle" as const },
};

export function RiskBadge({ level, score, size = "md" }: Props) {
  const colors = useColors();
  const color = level === "low" ? colors.riskLow : level === "medium" ? colors.riskMed : colors.riskHigh;
  const config = RISK_CONFIG[level];
  const isSmall = size === "sm";

  return (
    <View style={[styles.badge, {
      backgroundColor: color + "1A",
      borderColor: color + "50",
      paddingHorizontal: isSmall ? 7 : 10,
      paddingVertical: isSmall ? 3 : 5,
      gap: isSmall ? 4 : 5,
    }]}>
      <Feather name={config.icon} size={isSmall ? 10 : 12} color={color} />
      <Text style={[styles.label, { color, fontSize: isSmall ? 10 : 12 }]}>
        {isSmall ? level === "low" ? "Низкий" : level === "medium" ? "Средний" : "Высокий" : config.label}
      </Text>
      {score !== undefined && (
        <Text style={[styles.score, { color, fontSize: isSmall ? 10 : 12 }]}>{score}/10</Text>
      )}
    </View>
  );
}

export function RiskDots({ score }: { score: number }) {
  const colors = useColors();
  return (
    <View style={styles.dotsRow}>
      {Array.from({ length: 10 }).map((_, i) => {
        const filled = i < score;
        const color = i < 3 ? colors.riskLow : i < 6 ? colors.riskMed : colors.riskHigh;
        return (
          <View
            key={i}
            style={[styles.dot, {
              backgroundColor: filled ? color : color + "30",
              width: 6, height: 6,
            }]}
          />
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: "row", alignItems: "center", borderRadius: 100, borderWidth: 1,
  },
  label: { fontFamily: "Inter_600SemiBold" },
  score: { fontFamily: "Inter_700Bold", opacity: 0.8 },
  dotsRow: { flexDirection: "row", gap: 3 },
  dot: { borderRadius: 3 },
});
