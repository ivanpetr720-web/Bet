import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

type ThemeMode = "dark" | "light";

export interface PredictionHistoryItem {
  id: string;
  matchId: string;
  matchTitle: string;
  league: string;
  leagueFlag: string;
  date: string;
  betLabel: string;
  odds: number;
  stake: number;
  outcome: "won" | "lost" | "pending";
  profit: number;
  timestamp: number;
}

export interface TrackedOdds {
  matchId: string;
  matchTitle: string;
  betLabel: string;
  initialOdds: number;
  currentOdds: number;
  direction: "up" | "down" | "same";
  trackedAt: number;
}

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  timestamp: number;
  read: boolean;
  type: "live" | "odds" | "prediction" | "result";
}

export interface UserStats {
  totalBets: number;
  wonBets: number;
  lostBets: number;
  pendingBets: number;
  winRate: number;
  roi: number;
  totalProfit: number;
  totalStake: number;
  bestOddsWon: number;
}

interface AppContextType {
  theme: ThemeMode;
  toggleTheme: () => void;
  favorites: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  favTeams: string[];
  toggleFavTeam: (name: string) => void;
  isFavTeam: (name: string) => boolean;
  favLeagues: string[];
  toggleFavLeague: (code: string) => void;
  isFavLeague: (code: string) => boolean;
  history: PredictionHistoryItem[];
  addToHistory: (item: Omit<PredictionHistoryItem, "id" | "timestamp">) => void;
  updateOutcome: (id: string, outcome: "won" | "lost", profit: number) => void;
  clearHistory: () => void;
  userStats: UserStats;
  trackedOdds: TrackedOdds[];
  trackOdds: (item: Omit<TrackedOdds, "trackedAt" | "direction">) => void;
  removeTracked: (matchId: string, betLabel: string) => void;
  isTracked: (matchId: string, betLabel: string) => boolean;
  notifications: NotificationItem[];
  unreadCount: number;
  addNotification: (n: Omit<NotificationItem, "id" | "timestamp" | "read">) => void;
  markAllRead: () => void;
  notificationsEnabled: boolean;
  toggleNotifications: () => void;
}

const defaultStats: UserStats = {
  totalBets: 0, wonBets: 0, lostBets: 0, pendingBets: 0,
  winRate: 0, roi: 0, totalProfit: 0, totalStake: 0, bestOddsWon: 0,
};

const AppContext = createContext<AppContextType>({
  theme: "dark",
  toggleTheme: () => {},
  favorites: [],
  toggleFavorite: () => {},
  isFavorite: () => false,
  favTeams: [],
  toggleFavTeam: () => {},
  isFavTeam: () => false,
  favLeagues: [],
  toggleFavLeague: () => {},
  isFavLeague: () => false,
  history: [],
  addToHistory: () => {},
  updateOutcome: () => {},
  clearHistory: () => {},
  userStats: defaultStats,
  trackedOdds: [],
  trackOdds: () => {},
  removeTracked: () => {},
  isTracked: () => false,
  notifications: [],
  unreadCount: 0,
  addNotification: () => {},
  markAllRead: () => {},
  notificationsEnabled: true,
  toggleNotifications: () => {},
});

function computeStats(history: PredictionHistoryItem[]): UserStats {
  const settled = history.filter((h) => h.outcome !== "pending");
  const won = settled.filter((h) => h.outcome === "won");
  const totalProfit = settled.reduce((acc, h) => acc + h.profit, 0);
  const totalStake = settled.reduce((acc, h) => acc + h.stake, 0);
  const bestOddsWon = won.length > 0 ? Math.max(...won.map((h) => h.odds)) : 0;
  return {
    totalBets: settled.length,
    wonBets: won.length,
    lostBets: settled.filter((h) => h.outcome === "lost").length,
    pendingBets: history.filter((h) => h.outcome === "pending").length,
    winRate: settled.length > 0 ? (won.length / settled.length) * 100 : 0,
    roi: totalStake > 0 ? (totalProfit / totalStake) * 100 : 0,
    totalProfit,
    totalStake,
    bestOddsWon,
  };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeMode>("dark");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [favTeams, setFavTeams] = useState<string[]>([]);
  const [favLeagues, setFavLeagues] = useState<string[]>([]);
  const [history, setHistory] = useState<PredictionHistoryItem[]>([]);
  const [trackedOdds, setTrackedOdds] = useState<TrackedOdds[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  useEffect(() => {
    Promise.all([
      AsyncStorage.getItem("theme"),
      AsyncStorage.getItem("favorites"),
      AsyncStorage.getItem("favTeams"),
      AsyncStorage.getItem("favLeagues"),
      AsyncStorage.getItem("history"),
      AsyncStorage.getItem("trackedOdds"),
      AsyncStorage.getItem("notifications"),
      AsyncStorage.getItem("notificationsEnabled"),
    ]).then(([t, f, ft, fl, h, to, n, ne]) => {
      if (t === "light" || t === "dark") setTheme(t);
      if (f) setFavorites(JSON.parse(f));
      if (ft) setFavTeams(JSON.parse(ft));
      if (fl) setFavLeagues(JSON.parse(fl));
      if (h) setHistory(JSON.parse(h));
      if (to) setTrackedOdds(JSON.parse(to));
      if (n) setNotifications(JSON.parse(n));
      if (ne) setNotificationsEnabled(ne === "true");
    });
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((p) => {
      const next: ThemeMode = p === "dark" ? "light" : "dark";
      AsyncStorage.setItem("theme", next);
      return next;
    });
  }, []);

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((p) => {
      const next = p.includes(id) ? p.filter((x) => x !== id) : [...p, id];
      AsyncStorage.setItem("favorites", JSON.stringify(next));
      return next;
    });
  }, []);
  const isFavorite = useCallback((id: string) => favorites.includes(id), [favorites]);

  const toggleFavTeam = useCallback((name: string) => {
    setFavTeams((p) => {
      const next = p.includes(name) ? p.filter((x) => x !== name) : [...p, name];
      AsyncStorage.setItem("favTeams", JSON.stringify(next));
      return next;
    });
  }, []);
  const isFavTeam = useCallback((name: string) => favTeams.includes(name), [favTeams]);

  const toggleFavLeague = useCallback((code: string) => {
    setFavLeagues((p) => {
      const next = p.includes(code) ? p.filter((x) => x !== code) : [...p, code];
      AsyncStorage.setItem("favLeagues", JSON.stringify(next));
      return next;
    });
  }, []);
  const isFavLeague = useCallback((code: string) => favLeagues.includes(code), [favLeagues]);

  const addToHistory = useCallback((item: Omit<PredictionHistoryItem, "id" | "timestamp">) => {
    const newItem: PredictionHistoryItem = {
      ...item,
      id: Date.now().toString() + Math.random().toString(36).slice(2, 7),
      timestamp: Date.now(),
    };
    setHistory((p) => {
      const next = [newItem, ...p];
      AsyncStorage.setItem("history", JSON.stringify(next));
      return next;
    });
  }, []);

  const updateOutcome = useCallback((id: string, outcome: "won" | "lost", profit: number) => {
    setHistory((p) => {
      const next = p.map((h) => h.id === id ? { ...h, outcome, profit } : h);
      AsyncStorage.setItem("history", JSON.stringify(next));
      return next;
    });
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    AsyncStorage.setItem("history", "[]");
  }, []);

  const userStats = useMemo(() => computeStats(history), [history]);

  const trackOdds = useCallback((item: Omit<TrackedOdds, "trackedAt" | "direction">) => {
    const newItem: TrackedOdds = { ...item, direction: "same", trackedAt: Date.now() };
    setTrackedOdds((p) => {
      const exists = p.find((t) => t.matchId === item.matchId && t.betLabel === item.betLabel);
      const next = exists ? p : [...p, newItem];
      AsyncStorage.setItem("trackedOdds", JSON.stringify(next));
      return next;
    });
  }, []);

  const removeTracked = useCallback((matchId: string, betLabel: string) => {
    setTrackedOdds((p) => {
      const next = p.filter((t) => !(t.matchId === matchId && t.betLabel === betLabel));
      AsyncStorage.setItem("trackedOdds", JSON.stringify(next));
      return next;
    });
  }, []);

  const isTracked = useCallback(
    (matchId: string, betLabel: string) =>
      trackedOdds.some((t) => t.matchId === matchId && t.betLabel === betLabel),
    [trackedOdds]
  );

  const addNotification = useCallback((n: Omit<NotificationItem, "id" | "timestamp" | "read">) => {
    const item: NotificationItem = {
      ...n,
      id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
      timestamp: Date.now(),
      read: false,
    };
    setNotifications((p) => {
      const next = [item, ...p.slice(0, 49)];
      AsyncStorage.setItem("notifications", JSON.stringify(next));
      return next;
    });
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((p) => {
      const next = p.map((n) => ({ ...n, read: true }));
      AsyncStorage.setItem("notifications", JSON.stringify(next));
      return next;
    });
  }, []);

  const unreadCount = useMemo(() => notifications.filter((n) => !n.read).length, [notifications]);

  const toggleNotifications = useCallback(() => {
    setNotificationsEnabled((p) => {
      AsyncStorage.setItem("notificationsEnabled", String(!p));
      return !p;
    });
  }, []);

  return (
    <AppContext.Provider value={{
      theme, toggleTheme,
      favorites, toggleFavorite, isFavorite,
      favTeams, toggleFavTeam, isFavTeam,
      favLeagues, toggleFavLeague, isFavLeague,
      history, addToHistory, updateOutcome, clearHistory,
      userStats,
      trackedOdds, trackOdds, removeTracked, isTracked,
      notifications, unreadCount, addNotification, markAllRead,
      notificationsEnabled, toggleNotifications,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
