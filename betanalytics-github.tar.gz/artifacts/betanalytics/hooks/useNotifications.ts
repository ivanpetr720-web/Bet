import { useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { useMatches } from "./useMatches";

export async function registerForPushNotifications(): Promise<boolean> {
  return false;
}

export function useLiveMatchNotifications() {
  const { data: matches } = useMatches();
  const { notificationsEnabled, addNotification } = useApp();

  useEffect(() => {
    if (!matches || !notificationsEnabled) return;
    const liveMatches = matches.filter((m) => m.status === "live");
    for (const match of liveMatches) {
      addNotification({
        title: "Матч идёт!",
        body: `${match.homeTeam.shortName} ${match.score?.fullTime?.home ?? 0}:${match.score?.fullTime?.away ?? 0} ${match.awayTeam.shortName} — ${match.league}`,
        type: "live",
      });
    }
  }, []);
}
