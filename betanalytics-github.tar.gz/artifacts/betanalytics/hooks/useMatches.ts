import { useQuery } from "@tanstack/react-query";
import { Platform } from "react-native";

export interface TeamInfo {
  id: number;
  name: string;
  shortName: string;
  tla: string;
  crest: string;
  position: number | null;
  points: number | null;
  goalsFor: number | null;
  goalsAgainst: number | null;
  form: ("W" | "D" | "L")[];
}

export interface BookmakerOdds {
  bookmaker: string;
  home: number | null;
  draw: number | null;
  away: number | null;
  btts: number | null;
  over25: number | null;
}

export interface Tip {
  label: string;
  odds: number;
  value: number;
  confidence: number;
}

export interface Prediction {
  outcome: "home" | "draw" | "away";
  confidence: number;
  scoreline: string;
  btts: boolean;
  over25: boolean;
  valueOutcome: string;
  reasoning: string[];
  tips: Tip[];
  riskLevel: "low" | "medium" | "high";
  riskScore: number;
  aiInsight: string;
}

export interface H2HEntry {
  date: string;
  home: string;
  score: string;
  away: string;
  season: string;
}

export interface LiveMatch {
  id: string;
  fdId: number;
  league: string;
  leagueFlag: string;
  leagueCode: string;
  country: string;
  date: string;
  time: string;
  utcDate: string;
  status: "upcoming" | "live" | "finished";
  homeTeam: TeamInfo;
  awayTeam: TeamInfo;
  score?: { fullTime?: { home: number | null; away: number | null } };
  odds: BookmakerOdds[];
  prediction: Prediction;
  h2h: H2HEntry[];
}

function getApiBase(): string {
  // EXPO_PUBLIC_API_URL — явный URL для APK-сборок (устанавливается в Codemagic)
  const apiUrl = process.env["EXPO_PUBLIC_API_URL"];
  if (apiUrl) return apiUrl;
  // Веб-превью на Replit
  if (Platform.OS === "web") return "/api";
  // Expo Go / dev-сборки на Replit
  const domain = process.env["EXPO_PUBLIC_DOMAIN"];
  if (domain) return `https://${domain}/api`;
  return "/api";
}

async function fetchMatchesFn(): Promise<LiveMatch[]> {
  const base = getApiBase();
  const res = await fetch(`${base}/matches`, { signal: AbortSignal.timeout(10000) });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Ошибка сервера ${res.status}`);
  }
  const data = await res.json();
  if (!Array.isArray(data)) throw new Error("Неверный формат ответа от сервера");
  return data as LiveMatch[];
}

export function useMatches() {
  return useQuery<LiveMatch[], Error>({
    queryKey: ["matches"],
    queryFn: fetchMatchesFn,
    staleTime: 90_000,
    refetchInterval: 90_000,
    retry: 2,
  });
}

export function useMatch(id: string | undefined) {
  const { data: matches } = useMatches();
  return matches?.find((m) => m.id === id);
}

async function fetchMatchDetailFn(id: string): Promise<LiveMatch> {
  const base = getApiBase();
  const res = await fetch(`${base}/matches/${id}`, { signal: AbortSignal.timeout(10000) });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Ошибка сервера ${res.status}`);
  }
  return res.json() as Promise<LiveMatch>;
}

export function useMatchDetail(id: string | undefined) {
  return useQuery<LiveMatch, Error>({
    queryKey: ["match-detail", id],
    queryFn: () => fetchMatchDetailFn(id!),
    enabled: !!id,
    staleTime: 60_000,
    retry: 1,
  });
}

async function fetchAnalysisFn(id: string): Promise<Prediction> {
  const base = getApiBase();
  const res = await fetch(`${base}/matches/${id}/analysis`, { signal: AbortSignal.timeout(30000) });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Ошибка анализа ${res.status}`);
  }
  return res.json() as Promise<Prediction>;
}

export function useMatchAnalysis(id: string | undefined) {
  return useQuery<Prediction, Error>({
    queryKey: ["analysis", id],
    queryFn: () => fetchAnalysisFn(id!),
    enabled: !!id,
    staleTime: 300_000,
    retry: 1,
  });
}
