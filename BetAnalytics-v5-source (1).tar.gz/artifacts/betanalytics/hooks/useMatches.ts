import { useQuery } from "@tanstack/react-query";
import { Platform } from "react-native";

export interface TeamInfo {
  id: number;
  name: string;
  shortName: string;
  tla: string;
  crest: string;
  position: number | null;
  points: number | null;
  goalsFor: number | null;
  goalsAgainst: number | null;
  form: ("W" | "D" | "L")[];
}

export interface BookmakerOdds {
  bookmaker: string;
  home: number | null;
  draw: number | null;
  away: number | null;
  btts: number | null;
  over25: number | null;
}

export interface Tip {
  label: string;
  odds: number;
  value: number;
  confidence: number;
}

export interface Prediction {
  outcome: "home" | "draw" | "away";
  confidence: number;
  scoreline: string;
  btts: boolean;
  over25: boolean;
  valueOutcome: string;
  reasoning: string[];
  tips: Tip[];
  riskLevel: "low" | "medium" | "high";
  riskScore: number;
  aiInsight: string;
}

export interface H2HEntry {
  date: string;
  home: string;
  score: string;
  away: string;
  season: string;
}

export interface LiveMatch {
  id: string;
  fdId: number;
  league: string;
  leagueFlag: string;
  leagueCode: string;
  country: string;
  date: string;
  time: string;
  utcDate: string;
  status: "upcoming" | "live" | "finished";
  homeTeam: TeamInfo;
  awayTeam: TeamInfo;
  score?: { fullTime?: { home: number | null; away: number | null } };
  odds: BookmakerOdds[];
  prediction: Prediction;
  h2h: H2HEntry[];
}

const MOCK_MATCHES: LiveMatch[] = [
  {
    id: "m1", fdId: 101, league: "Премьер-лига", leagueFlag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    leagueCode: "PL", country: "England", date: "02.06", time: "22:00",
    utcDate: "2026-06-02T19:00:00Z", status: "upcoming",
    homeTeam: {
      id: 65, name: "Manchester City", shortName: "Man City", tla: "MCI",
      crest: "https://crests.football-data.org/65.png",
      position: 2, points: 72, goalsFor: 68, goalsAgainst: 33,
      form: ["W", "W", "D", "W", "L"],
    },
    awayTeam: {
      id: 57, name: "Arsenal", shortName: "Arsenal", tla: "ARS",
      crest: "https://crests.football-data.org/57.png",
      position: 1, points: 77, goalsFor: 73, goalsAgainst: 28,
      form: ["W", "W", "W", "D", "W"],
    },
    odds: [
      { bookmaker: "Bet365", home: 3.20, draw: 3.40, away: 2.10, btts: 1.72, over25: 1.65 },
      { bookmaker: "1xBet", home: 3.35, draw: 3.50, away: 2.15, btts: 1.75, over25: 1.68 },
      { bookmaker: "Bwin", home: 3.10, draw: 3.30, away: 2.05, btts: 1.70, over25: 1.62 },
    ],
    prediction: {
      outcome: "away", confidence: 68, scoreline: "1–2", btts: true, over25: true,
      valueOutcome: "Победа Arsenal", riskLevel: "medium", riskScore: 5,
      aiInsight: "Arsenal лидирует в АПЛ с отрывом 5 очков. Man City нестабилен без Холанда — 3 матча без победы.",
      reasoning: [
        "Arsenal ведёт в таблице с отрывом 5 очков от Man City",
        "Команда Гвардиолы нестабильна без Холанда — последние 3 матча без побед",
        "Arsenal выиграл 3 из последних 4 личных встреч на Этихаде",
        "Оба клуба забивают стабильно: ожидаем голы с обеих сторон",
      ],
      tips: [
        { label: "Победа Arsenal (П2)", odds: 2.15, value: 0.18, confidence: 68 },
        { label: "Обе забьют — Да", odds: 1.75, value: 0.12, confidence: 71 },
        { label: "Тотал больше 2.5", odds: 1.68, value: 0.09, confidence: 65 },
      ],
    },
    h2h: [
      { date: "07.10.25", home: "Arsenal", score: "2–0", away: "Man City", season: "25/26" },
      { date: "31.03.25", home: "Man City", score: "1–1", away: "Arsenal", season: "24/25" },
      { date: "08.10.24", home: "Arsenal", score: "3–1", away: "Man City", season: "24/25" },
      { date: "26.03.24", home: "Man City", score: "0–1", away: "Arsenal", season: "23/24" },
      { date: "06.01.24", home: "Arsenal", score: "1–0", away: "Man City", season: "23/24" },
    ],
  },
  {
    id: "m2", fdId: 102, league: "Ла Лига", leagueFlag: "🇪🇸",
    leagueCode: "PD", country: "Spain", date: "02.06", time: "22:00",
    utcDate: "2026-06-02T19:00:00Z", status: "upcoming",
    homeTeam: {
      id: 86, name: "Real Madrid", shortName: "Real Madrid", tla: "RMA",
      crest: "https://crests.football-data.org/86.png",
      position: 1, points: 84, goalsFor: 79, goalsAgainst: 24,
      form: ["W", "W", "W", "W", "D"],
    },
    awayTeam: {
      id: 81, name: "FC Barcelona", shortName: "Barcelona", tla: "FCB",
      crest: "https://crests.football-data.org/81.png",
      position: 2, points: 78, goalsFor: 71, goalsAgainst: 31,
      form: ["W", "D", "W", "W", "L"],
    },
    odds: [
      { bookmaker: "Bet365", home: 2.10, draw: 3.50, away: 3.40, btts: 1.68, over25: 1.60 },
      { bookmaker: "1xBet", home: 2.15, draw: 3.60, away: 3.45, btts: 1.70, over25: 1.62 },
      { bookmaker: "Bwin", home: 2.05, draw: 3.40, away: 3.30, btts: 1.65, over25: 1.58 },
    ],
    prediction: {
      outcome: "home", confidence: 72, scoreline: "2–1", btts: true, over25: true,
      valueOutcome: "Победа Real Madrid", riskLevel: "low", riskScore: 3,
      aiInsight: "Класико! Real Madrid доминирует дома в этом сезоне — 12 побед из 14 домашних матчей.",
      reasoning: [
        "Real Madrid непобедим на Бернабеу в этом сезоне: 12 побед из 14",
        "Барселона нестабильна в выездных матчах — 3 поражения в последних 6",
        "Мбаппе в великолепной форме: 8 голов в последних 6 матчах",
        "Исторически Real выигрывает 58% домашних Класико",
      ],
      tips: [
        { label: "Победа Real Madrid (П1)", odds: 2.15, value: 0.22, confidence: 72 },
        { label: "Обе забьют — Да", odds: 1.70, value: 0.15, confidence: 74 },
        { label: "Тотал больше 2.5", odds: 1.62, value: 0.11, confidence: 68 },
      ],
    },
    h2h: [
      { date: "26.10.25", home: "Barcelona", score: "1–4", away: "Real Madrid", season: "25/26" },
      { date: "16.03.25", home: "Real Madrid", score: "3–2", away: "Barcelona", season: "24/25" },
      { date: "26.10.24", home: "Barcelona", score: "0–4", away: "Real Madrid", season: "24/25" },
      { date: "21.04.24", home: "Real Madrid", score: "3–2", away: "Barcelona", season: "23/24" },
      { date: "28.10.23", home: "Barcelona", score: "1–2", away: "Real Madrid", season: "23/24" },
    ],
  },
  {
    id: "m3", fdId: 103, league: "Бундеслига", leagueFlag: "🇩🇪",
    leagueCode: "BL1", country: "Germany", date: "01.06", time: "18:30",
    utcDate: "2026-06-01T15:30:00Z", status: "live",
    homeTeam: {
      id: 5, name: "Bayern München", shortName: "Bayern", tla: "FCB",
      crest: "https://crests.football-data.org/5.png",
      position: 1, points: 79, goalsFor: 88, goalsAgainst: 29,
      form: ["W", "W", "W", "D", "W"],
    },
    awayTeam: {
      id: 4, name: "Borussia Dortmund", shortName: "Dortmund", tla: "BVB",
      crest: "https://crests.football-data.org/4.png",
      position: 3, points: 60, goalsFor: 62, goalsAgainst: 48,
      form: ["D", "W", "L", "W", "D"],
    },
    score: { fullTime: { home: 1, away: 0 } },
    odds: [
      { bookmaker: "Bet365", home: 1.75, draw: 4.00, away: 4.50, btts: 1.70, over25: 1.55 },
      { bookmaker: "1xBet", home: 1.78, draw: 4.10, away: 4.60, btts: 1.72, over25: 1.57 },
      { bookmaker: "Bwin", home: 1.72, draw: 3.90, away: 4.40, btts: 1.68, over25: 1.53 },
    ],
    prediction: {
      outcome: "home", confidence: 65, scoreline: "3–1", btts: true, over25: true,
      valueOutcome: "Победа Bayern", riskLevel: "low", riskScore: 2,
      aiInsight: "Дерби Германии! Bayern забивает в среднем 3.1 гола дома. Kane в отличной форме.",
      reasoning: [
        "Bayern в среднем забивает 3.1 гола за домашний матч в этом сезоне",
        "Kane забил 8 голов в последних 7 матчах Бундеслиги",
        "Дортмунд пропустил 15 голов в последних 7 выездных матчах",
        "Die Roten выиграли 8 из последних 10 домашних Дерби",
      ],
      tips: [
        { label: "Победа Bayern (П1)", odds: 1.78, value: 0.14, confidence: 65 },
        { label: "Тотал больше 2.5", odds: 1.57, value: 0.10, confidence: 70 },
        { label: "Обе забьют — Да", odds: 1.72, value: 0.08, confidence: 62 },
      ],
    },
    h2h: [
      { date: "09.11.25", home: "Dortmund", score: "1–3", away: "Bayern", season: "25/26" },
      { date: "30.03.25", home: "Bayern", score: "4–0", away: "Dortmund", season: "24/25" },
      { date: "09.11.24", home: "Dortmund", score: "1–1", away: "Bayern", season: "24/25" },
      { date: "30.03.24", home: "Bayern", score: "2–0", away: "Dortmund", season: "23/24" },
      { date: "04.11.23", home: "Dortmund", score: "0–4", away: "Bayern", season: "23/24" },
    ],
  },
  {
    id: "m4", fdId: 104, league: "Лига 1", leagueFlag: "🇫🇷",
    leagueCode: "FL1", country: "France", date: "02.06", time: "20:00",
    utcDate: "2026-06-02T17:00:00Z", status: "upcoming",
    homeTeam: {
      id: 524, name: "Paris Saint-Germain", shortName: "PSG", tla: "PSG",
      crest: "https://crests.football-data.org/524.png",
      position: 1, points: 88, goalsFor: 92, goalsAgainst: 22,
      form: ["W", "W", "W", "W", "W"],
    },
    awayTeam: {
      id: 523, name: "Olympique Lyon", shortName: "Lyon", tla: "OL",
      crest: "https://crests.football-data.org/523.png",
      position: 4, points: 57, goalsFor: 52, goalsAgainst: 44,
      form: ["L", "W", "D", "W", "L"],
    },
    odds: [
      { bookmaker: "Bet365", home: 1.45, draw: 4.50, away: 6.50, btts: 1.80, over25: 1.55 },
      { bookmaker: "1xBet", home: 1.47, draw: 4.60, away: 6.60, btts: 1.82, over25: 1.57 },
      { bookmaker: "Bwin", home: 1.43, draw: 4.40, away: 6.40, btts: 1.78, over25: 1.53 },
    ],
    prediction: {
      outcome: "home", confidence: 82, scoreline: "3–0", btts: false, over25: true,
      valueOutcome: "Победа PSG", riskLevel: "low", riskScore: 1,
      aiInsight: "PSG доминирует в Лига 1 с огромным отрывом. Лион без ключевых игроков из-за травм.",
      reasoning: [
        "PSG выиграл 26 из 34 матчей сезона — абсолютное доминирование",
        "Лион проиграл 4 из последних 6 выездных матчей",
        "У Лиона травмированы 4 ключевых игрока оборонительной линии",
        "PSG не проигрывал дома уже 18 матчей подряд в чемпионате",
      ],
      tips: [
        { label: "Победа PSG (П1)", odds: 1.47, value: 0.07, confidence: 82 },
        { label: "Тотал больше 2.5", odds: 1.57, value: 0.12, confidence: 78 },
        { label: "Фора PSG (-1.5)", odds: 1.85, value: 0.16, confidence: 65 },
      ],
    },
    h2h: [
      { date: "25.01.26", home: "Lyon", score: "0–3", away: "PSG", season: "25/26" },
      { date: "03.11.25", home: "PSG", score: "4–1", away: "Lyon", season: "25/26" },
      { date: "19.01.25", home: "Lyon", score: "1–4", away: "PSG", season: "24/25" },
      { date: "27.10.24", home: "PSG", score: "2–1", away: "Lyon", season: "24/25" },
      { date: "28.04.24", home: "PSG", score: "3–2", away: "Lyon", season: "23/24" },
    ],
  },
  {
    id: "m5", fdId: 105, league: "Серия А", leagueFlag: "🇮🇹",
    leagueCode: "SA", country: "Italy", date: "01.06", time: "21:45",
    utcDate: "2026-06-01T18:45:00Z", status: "finished",
    homeTeam: {
      id: 109, name: "Juventus FC", shortName: "Juventus", tla: "JUV",
      crest: "https://crests.football-data.org/109.png",
      position: 3, points: 67, goalsFor: 58, goalsAgainst: 35,
      form: ["W", "D", "W", "W", "D"],
    },
    awayTeam: {
      id: 108, name: "Inter Milan", shortName: "Inter", tla: "INT",
      crest: "https://crests.football-data.org/108.png",
      position: 1, points: 76, goalsFor: 74, goalsAgainst: 28,
      form: ["W", "W", "L", "W", "W"],
    },
    score: { fullTime: { home: 2, away: 1 } },
    odds: [
      { bookmaker: "Bet365", home: 2.50, draw: 3.30, away: 2.80, btts: 1.65, over25: 1.70 },
      { bookmaker: "1xBet", home: 2.55, draw: 3.40, away: 2.85, btts: 1.67, over25: 1.72 },
      { bookmaker: "Bwin", home: 2.45, draw: 3.20, away: 2.75, btts: 1.63, over25: 1.68 },
    ],
    prediction: {
      outcome: "home", confidence: 61, scoreline: "2–1", btts: true, over25: true,
      valueOutcome: "Победа Juventus", riskLevel: "medium", riskScore: 5,
      aiInsight: "Дерби д'Италия! Оба клуба в хорошей форме, но Juventus дома очень силён.",
      reasoning: [
        "Juventus выиграл 9 из последних 12 домашних матчей",
        "Inter проигрывал в 2 из последних 5 выездных матчей",
        "Влахович забил в 3 последних домашних матчах",
        "Высокая мотивация Juventus — игра напрямую влияет на место в таблице",
      ],
      tips: [
        { label: "Победа Juventus (П1)", odds: 2.55, value: 0.14, confidence: 61 },
        { label: "Обе забьют — Да", odds: 1.67, value: 0.10, confidence: 63 },
        { label: "Тотал больше 2.5", odds: 1.72, value: 0.08, confidence: 60 },
      ],
    },
    h2h: [
      { date: "26.10.25", home: "Inter", score: "1–2", away: "Juventus", season: "25/26" },
      { date: "27.04.25", home: "Juventus", score: "1–0", away: "Inter", season: "24/25" },
      { date: "27.10.24", home: "Inter", score: "0–4", away: "Juventus", season: "24/25" },
      { date: "06.04.24", home: "Juventus", score: "1–1", away: "Inter", season: "23/24" },
      { date: "06.11.23", home: "Inter", score: "1–0", away: "Juventus", season: "23/24" },
    ],
  },
  {
    id: "m6", fdId: 106, league: "Премьер-лига", leagueFlag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    leagueCode: "PL", country: "England", date: "03.06", time: "17:30",
    utcDate: "2026-06-03T14:30:00Z", status: "upcoming",
    homeTeam: {
      id: 64, name: "Liverpool FC", shortName: "Liverpool", tla: "LIV",
      crest: "https://crests.football-data.org/64.png",
      position: 3, points: 69, goalsFor: 71, goalsAgainst: 37,
      form: ["W", "W", "W", "W", "D"],
    },
    awayTeam: {
      id: 61, name: "Chelsea FC", shortName: "Chelsea", tla: "CHE",
      crest: "https://crests.football-data.org/61.png",
      position: 5, points: 62, goalsFor: 59, goalsAgainst: 42,
      form: ["L", "W", "D", "W", "L"],
    },
    odds: [
      { bookmaker: "Bet365", home: 1.85, draw: 3.60, away: 4.20, btts: 1.72, over25: 1.60 },
      { bookmaker: "1xBet", home: 1.88, draw: 3.70, away: 4.30, btts: 1.74, over25: 1.62 },
      { bookmaker: "Bwin", home: 1.82, draw: 3.50, away: 4.10, btts: 1.70, over25: 1.58 },
    ],
    prediction: {
      outcome: "home", confidence: 75, scoreline: "2–1", btts: true, over25: true,
      valueOutcome: "Победа Liverpool", riskLevel: "low", riskScore: 3,
      aiInsight: "Liverpool непобедим на Энфилде уже 14 матчей подряд. Chelsea нестабилен в гостях.",
      reasoning: [
        "Liverpool не проигрывал на Энфилде уже 14 матчей подряд в АПЛ",
        "Chelsea проиграл 4 из последних 7 выездных матчей",
        "Салах в великолепной форме — 6 голов в последних 5 матчах",
        "Первый выход Джоты в стартовом составе после травмы усиливает атаку",
      ],
      tips: [
        { label: "Победа Liverpool (П1)", odds: 1.88, value: 0.20, confidence: 75 },
        { label: "Обе забьют — Да", odds: 1.74, value: 0.13, confidence: 72 },
        { label: "Тотал больше 2.5", odds: 1.62, value: 0.10, confidence: 70 },
      ],
    },
    h2h: [
      { date: "02.02.26", home: "Chelsea", score: "1–2", away: "Liverpool", season: "25/26" },
      { date: "13.10.25", home: "Liverpool", score: "3–1", away: "Chelsea", season: "25/26" },
      { date: "01.02.25", home: "Chelsea", score: "0–2", away: "Liverpool", season: "24/25" },
      { date: "22.09.24", home: "Liverpool", score: "2–1", away: "Chelsea", season: "24/25" },
      { date: "31.01.24", home: "Chelsea", score: "4–1", away: "Liverpool", season: "23/24" },
    ],
  },
  {
    id: "m7", fdId: 107, league: "Ла Лига", leagueFlag: "🇪🇸",
    leagueCode: "PD", country: "Spain", date: "03.06", time: "20:00",
    utcDate: "2026-06-03T17:00:00Z", status: "upcoming",
    homeTeam: {
      id: 78, name: "Atletico de Madrid", shortName: "Atletico", tla: "ATM",
      crest: "https://crests.football-data.org/78.png",
      position: 3, points: 71, goalsFor: 55, goalsAgainst: 28,
      form: ["D", "W", "D", "L", "W"],
    },
    awayTeam: {
      id: 94, name: "Villarreal CF", shortName: "Villarreal", tla: "VIL",
      crest: "https://crests.football-data.org/94.png",
      position: 6, points: 55, goalsFor: 48, goalsAgainst: 43,
      form: ["W", "D", "L", "D", "W"],
    },
    odds: [
      { bookmaker: "Bet365", home: 2.00, draw: 3.20, away: 3.80, btts: 1.75, over25: 1.72 },
      { bookmaker: "1xBet", home: 2.05, draw: 3.30, away: 3.90, btts: 1.77, over25: 1.74 },
      { bookmaker: "Bwin", home: 1.95, draw: 3.10, away: 3.70, btts: 1.73, over25: 1.70 },
    ],
    prediction: {
      outcome: "draw", confidence: 52, scoreline: "1–1", btts: true, over25: false,
      valueOutcome: "Ничья", riskLevel: "high", riskScore: 7,
      aiInsight: "Сложный матч. Атлетико играет оборонительно дома. Вильярреал хорошо держится в гостях.",
      reasoning: [
        "Атлетико сыграл вничью в 4 из последних 7 домашних матчей",
        "Вильярреал не проигрывает в последних 5 выездных играх",
        "Тактика Симеоне предусматривает плотную оборону — мало голов",
        "Форма обеих команд нестабильна — сложно прогнозировать",
      ],
      tips: [
        { label: "Ничья (Х)", odds: 3.30, value: 0.08, confidence: 52 },
        { label: "Тотал меньше 2.5", odds: 2.00, value: 0.12, confidence: 58 },
        { label: "Обе забьют — Нет", odds: 1.85, value: 0.09, confidence: 55 },
      ],
    },
    h2h: [
      { date: "18.01.26", home: "Villarreal", score: "1–1", away: "Atletico", season: "25/26" },
      { date: "07.09.25", home: "Atletico", score: "2–0", away: "Villarreal", season: "25/26" },
      { date: "12.01.25", home: "Villarreal", score: "2–2", away: "Atletico", season: "24/25" },
      { date: "08.09.24", home: "Atletico", score: "0–1", away: "Villarreal", season: "24/25" },
      { date: "05.05.24", home: "Atletico", score: "2–1", away: "Villarreal", season: "23/24" },
    ],
  },
  {
    id: "m8", fdId: 108, league: "Эредивизи", leagueFlag: "🇳🇱",
    leagueCode: "DED", country: "Netherlands", date: "03.06", time: "18:45",
    utcDate: "2026-06-03T15:45:00Z", status: "upcoming",
    homeTeam: {
      id: 610, name: "Ajax Amsterdam", shortName: "Ajax", tla: "AJA",
      crest: "https://crests.football-data.org/610.png",
      position: 1, points: 77, goalsFor: 86, goalsAgainst: 31,
      form: ["W", "W", "W", "D", "W"],
    },
    awayTeam: {
      id: 674, name: "PSV Eindhoven", shortName: "PSV", tla: "PSV",
      crest: "https://crests.football-data.org/674.png",
      position: 2, points: 72, goalsFor: 81, goalsAgainst: 28,
      form: ["W", "W", "L", "W", "W"],
    },
    odds: [
      { bookmaker: "Bet365", home: 1.95, draw: 3.40, away: 3.80, btts: 1.60, over25: 1.50 },
      { bookmaker: "1xBet", home: 1.98, draw: 3.50, away: 3.90, btts: 1.62, over25: 1.52 },
      { bookmaker: "Bwin", home: 1.92, draw: 3.30, away: 3.70, btts: 1.58, over25: 1.48 },
    ],
    prediction: {
      outcome: "home", confidence: 63, scoreline: "2–1", btts: true, over25: true,
      valueOutcome: "Победа Ajax", riskLevel: "medium", riskScore: 4,
      aiInsight: "Топ-матч Эредивизи! Оба клуба много забивают. Ajax дома очень опасен.",
      reasoning: [
        "Ajax в среднем забивает 2.8 гола за домашний матч",
        "PSV проиграл 2 из последних 5 выездных матчей",
        "Оба клуба имеют высокие xG — ожидаем результативный матч",
        "Историческое преимущество Ajax в домашних встречах с PSV",
      ],
      tips: [
        { label: "Победа Ajax (П1)", odds: 1.98, value: 0.10, confidence: 63 },
        { label: "Тотал больше 2.5", odds: 1.52, value: 0.13, confidence: 72 },
        { label: "Обе забьют — Да", odds: 1.62, value: 0.11, confidence: 70 },
      ],
    },
    h2h: [
      { date: "19.10.25", home: "PSV", score: "1–2", away: "Ajax", season: "25/26" },
      { date: "18.01.25", home: "Ajax", score: "3–1", away: "PSV", season: "24/25" },
      { date: "20.10.24", home: "PSV", score: "2–2", away: "Ajax", season: "24/25" },
      { date: "19.01.24", home: "Ajax", score: "2–2", away: "PSV", season: "23/24" },
      { date: "05.11.23", home: "PSV", score: "1–0", away: "Ajax", season: "23/24" },
    ],
  },
];

async function fetchMatchesFn(): Promise<LiveMatch[]> {
  const domain = process.env["EXPO_PUBLIC_DOMAIN"];
  if (!domain) return MOCK_MATCHES;
  try {
    const base = Platform.OS === "web" ? "/api" : `https://${domain}/api`;
    const res = await fetch(`${base}/matches`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return MOCK_MATCHES;
    const data = await res.json();
    return Array.isArray(data) && data.length > 0 ? data : MOCK_MATCHES;
  } catch {
    return MOCK_MATCHES;
  }
}

export function useMatches() {
  return useQuery<LiveMatch[]>({
    queryKey: ["matches"],
    queryFn: fetchMatchesFn,
    staleTime: 90_000,
    refetchInterval: 90_000,
    retry: 1,
    initialData: MOCK_MATCHES,
  });
}

export function useMatch(id: string | undefined) {
  const { data: matches } = useMatches();
  return matches?.find((m) => m.id === id);
}
