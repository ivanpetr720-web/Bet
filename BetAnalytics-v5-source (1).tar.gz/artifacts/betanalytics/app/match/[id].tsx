import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ConfidenceBar } from "@/components/ConfidenceBar";
import { FormBadges } from "@/components/FormBadges";
import { RiskBadge, RiskDots } from "@/components/RiskBadge";
import { TeamLogo } from "@/components/TeamLogo";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { useMatch } from "@/hooks/useMatches";

type DetailTab = "overview" | "h2h" | "form" | "betting";

export default function MatchDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const match = useMatch(id);
  const { isFavorite, toggleFavorite, addToHistory, isTracked, trackOdds, removeTracked } = useApp();
  const [tab, setTab] = useState<DetailTab>("overview");
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedTip, setSelectedTip] = useState<{ label: string; odds: number } | null>(null);
  const [stake, setStake] = useState("100");

  if (!match) {
    return (
      <View style={[styles.loading, { backgroundColor: colors.background }]}>
        <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Матч не найден</Text>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.surface }]}>
          <Feather name="arrow-left" size={16} color={colors.foreground} />
          <Text style={[styles.backBtnText, { color: colors.foreground }]}>Назад</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const fav = isFavorite(match.id);
  const isLive = match.status === "live";
  const isFinished = match.status === "finished";

  const confColor =
    match.prediction.confidence >= 70 ? colors.win
    : match.prediction.confidence >= 55 ? colors.draw
    : colors.loss;

  const homeWins = match.h2h.filter((h) => {
    const [hg, ag] = h.score.split("–").map(Number);
    return h.home === match.homeTeam.shortName ? hg > ag : ag > hg;
  }).length;
  const awayWins = match.h2h.filter((h) => {
    const [hg, ag] = h.score.split("–").map(Number);
    return h.away === match.homeTeam.shortName ? hg > ag : ag > hg;
  }).length;
  const draws = match.h2h.length - homeWins - awayWins;

  const handleAddTip = (tipLabel: string, tipOdds: number) => {
    setSelectedTip({ label: tipLabel, odds: tipOdds });
    setShowAddModal(true);
  };

  const handleConfirmAdd = () => {
    if (!selectedTip) return;
    const stakeNum = parseFloat(stake);
    if (isNaN(stakeNum) || stakeNum <= 0) {
      Alert.alert("Ошибка", "Введите корректную сумму ставки");
      return;
    }
    addToHistory({
      matchId: match.id,
      matchTitle: `${match.homeTeam.shortName} – ${match.awayTeam.shortName}`,
      league: match.league,
      leagueFlag: match.leagueFlag,
      date: match.date,
      betLabel: selectedTip.label,
      odds: selectedTip.odds,
      stake: stakeNum,
      outcome: "pending",
      profit: -stakeNum,
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowAddModal(false);
    Alert.alert("✅ Добавлено в историю", `${selectedTip.label} @ ${selectedTip.odds.toFixed(2)}\nСтавка: ${stakeNum}₽`);
  };

  const tabs: { id: DetailTab; label: string }[] = [
    { id: "overview", label: "Обзор" },
    { id: "h2h", label: "H2H" },
    { id: "form", label: "Форма" },
    { id: "betting", label: "Ставки" },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={[confColor + "40", colors.background]}
        start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }}
        style={[styles.topGrad, { height: Platform.OS === "web" ? 240 : insets.top + 240 }]}
        pointerEvents="none"
      />

      <View style={[styles.navBar, { paddingTop: Platform.OS === "web" ? 52 : insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.navBtn, { backgroundColor: colors.card + "CC", borderColor: colors.border }]}>
          <Feather name="arrow-left" size={18} color={colors.foreground} />
        </TouchableOpacity>
        <View style={styles.navLeague}>
          <Text style={styles.navFlag}>{match.leagueFlag}</Text>
          <Text style={[styles.navLeagueText, { color: colors.mutedForeground }]}>{match.league}</Text>
        </View>
        <TouchableOpacity
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            toggleFavorite(match.id);
          }}
          style={[styles.navBtn, {
            backgroundColor: fav ? colors.primary + "22" : colors.card + "CC",
            borderColor: fav ? colors.primary + "60" : colors.border,
          }]}
        >
          <Feather name="bookmark" size={18} color={fav ? colors.primary : colors.foreground} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 24 }}>
        <View style={styles.hero}>
          <View style={styles.teamsRow}>
            <View style={styles.teamBlock}>
              <TeamLogo crest={match.homeTeam.crest} tla={match.homeTeam.tla} size={64} />
              <Text style={[styles.teamName, { color: colors.foreground }]} numberOfLines={2}>{match.homeTeam.shortName}</Text>
              {match.homeTeam.position && (
                <Text style={[styles.teamPos, { color: colors.mutedForeground }]}>#{match.homeTeam.position} · {match.homeTeam.points}оч</Text>
              )}
            </View>

            <View style={styles.centreBadge}>
              {isLive && match.score?.fullTime?.home != null ? (
                <View style={[styles.scoreCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <View style={[styles.livePill, { backgroundColor: colors.loss + "22", borderColor: colors.loss }]}>
                    <View style={[styles.liveDot, { backgroundColor: colors.loss }]} />
                    <Text style={[styles.liveTxt, { color: colors.loss }]}>LIVE</Text>
                  </View>
                  <Text style={[styles.scoreLarge, { color: colors.foreground }]}>
                    {match.score.fullTime.home} : {match.score.fullTime.away}
                  </Text>
                </View>
              ) : isFinished && match.score?.fullTime?.home != null ? (
                <View style={[styles.scoreCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>ИТОГ</Text>
                  <Text style={[styles.scoreLarge, { color: colors.foreground }]}>
                    {match.score.fullTime.home} : {match.score.fullTime.away}
                  </Text>
                </View>
              ) : (
                <View style={[styles.scoreCard, { backgroundColor: colors.card, borderColor: colors.primary + "55" }]}>
                  <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>{match.date} · {match.time}</Text>
                  <Text style={[styles.scoreLarge, { color: colors.primary }]}>{match.prediction.scoreline}</Text>
                  <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>прогноз</Text>
                </View>
              )}
            </View>

            <View style={[styles.teamBlock, styles.teamBlockRight]}>
              <TeamLogo crest={match.awayTeam.crest} tla={match.awayTeam.tla} size={64} />
              <Text style={[styles.teamName, { color: colors.foreground }]} numberOfLines={2}>{match.awayTeam.shortName}</Text>
              {match.awayTeam.position && (
                <Text style={[styles.teamPos, { color: colors.mutedForeground }]}>#{match.awayTeam.position} · {match.awayTeam.points}оч</Text>
              )}
            </View>
          </View>
        </View>

        <View style={[styles.tabBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {tabs.map((t) => (
            <TouchableOpacity
              key={t.id}
              style={[styles.tabBtn, tab === t.id ? { borderBottomColor: colors.primary } : { borderBottomColor: "transparent" }]}
              onPress={() => setTab(t.id)}
            >
              <Text style={[styles.tabTxt, { color: tab === t.id ? colors.primary : colors.mutedForeground }]}>{t.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.body}>
          {tab === "overview" && (
            <View style={styles.section}>
              <ConfidenceBar confidence={match.prediction.confidence} />

              <View style={styles.riskRow}>
                <RiskBadge level={match.prediction.riskLevel} score={match.prediction.riskScore} />
                <RiskDots score={match.prediction.riskScore} />
              </View>

              <View style={[styles.aiCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.aiHeader}>
                  <View style={[styles.aiIcon, { backgroundColor: colors.primary + "22" }]}>
                    <Feather name="cpu" size={14} color={colors.primary} />
                  </View>
                  <Text style={[styles.aiTitle, { color: colors.foreground }]}>ИИ Анализ</Text>
                </View>
                <Text style={[styles.aiInsight, { color: colors.foreground }]}>{match.prediction.aiInsight}</Text>
                <View style={styles.reasonList}>
                  {match.prediction.reasoning.map((r, i) => (
                    <View key={i} style={styles.reasonItem}>
                      <View style={[styles.reasonDot, { backgroundColor: colors.primary }]} />
                      <Text style={[styles.reasonText, { color: colors.foreground }]}>{r}</Text>
                    </View>
                  ))}
                </View>
              </View>

              <View style={styles.tagsRow}>
                <View style={[styles.tag, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={[styles.tagLabel, { color: colors.mutedForeground }]}>Тотал > 2.5</Text>
                  <Text style={[styles.tagVal, { color: match.prediction.over25 ? colors.win : colors.loss }]}>
                    {match.prediction.over25 ? "Да ✓" : "Нет ✗"}
                  </Text>
                </View>
                <View style={[styles.tag, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={[styles.tagLabel, { color: colors.mutedForeground }]}>Обе забьют</Text>
                  <Text style={[styles.tagVal, { color: match.prediction.btts ? colors.win : colors.loss }]}>
                    {match.prediction.btts ? "Да ✓" : "Нет ✗"}
                  </Text>
                </View>
                <View style={[styles.tag, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={[styles.tagLabel, { color: colors.mutedForeground }]}>Исход</Text>
                  <Text style={[styles.tagVal, { color: colors.primary }]}>
                    {match.prediction.outcome === "home" ? "П1" : match.prediction.outcome === "draw" ? "X" : "П2"}
                  </Text>
                </View>
              </View>
            </View>
          )}

          {tab === "h2h" && (
            <View style={styles.section}>
              <View style={styles.h2hStats}>
                <View style={[styles.h2hStatBox, { backgroundColor: colors.win + "15", borderColor: colors.win + "40" }]}>
                  <Text style={[styles.h2hStatNum, { color: colors.win }]}>{homeWins}</Text>
                  <Text style={[styles.h2hStatLabel, { color: colors.mutedForeground }]} numberOfLines={1}>{match.homeTeam.tla}</Text>
                </View>
                <View style={[styles.h2hStatBox, { backgroundColor: colors.draw + "15", borderColor: colors.draw + "40" }]}>
                  <Text style={[styles.h2hStatNum, { color: colors.draw }]}>{draws}</Text>
                  <Text style={[styles.h2hStatLabel, { color: colors.mutedForeground }]}>Ничьи</Text>
                </View>
                <View style={[styles.h2hStatBox, { backgroundColor: colors.win + "15", borderColor: colors.win + "40" }]}>
                  <Text style={[styles.h2hStatNum, { color: colors.win }]}>{awayWins}</Text>
                  <Text style={[styles.h2hStatLabel, { color: colors.mutedForeground }]} numberOfLines={1}>{match.awayTeam.tla}</Text>
                </View>
              </View>

              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Последние встречи</Text>
              {match.h2h.map((h, i) => {
                const [hg, ag] = h.score.split("–").map(Number);
                const homeWon = hg > ag;
                const isHomeMatchHome = h.home === match.homeTeam.shortName;
                const color = hg === ag ? colors.draw : (isHomeMatchHome ? (homeWon ? colors.win : colors.loss) : (homeWon ? colors.loss : colors.win));
                return (
                  <View key={i} style={[styles.h2hRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
                    <View style={[styles.h2hStripe, { backgroundColor: color }]} />
                    <Text style={[styles.h2hDate, { color: colors.mutedForeground }]}>{h.date}</Text>
                    <View style={styles.h2hTeams}>
                      <Text style={[styles.h2hTeam, { color: colors.foreground }]} numberOfLines={1}>{h.home}</Text>
                      <Text style={[styles.h2hScore, { color: color }]}>{h.score}</Text>
                      <Text style={[styles.h2hTeam, { color: colors.foreground, textAlign: "right" }]} numberOfLines={1}>{h.away}</Text>
                    </View>
                    <Text style={[styles.h2hSeason, { color: colors.mutedForeground }]}>{h.season}</Text>
                  </View>
                );
              })}
            </View>
          )}

          {tab === "form" && (
            <View style={styles.section}>
              {[
                { team: match.homeTeam, side: "Хозяева" },
                { team: match.awayTeam, side: "Гости" },
              ].map(({ team, side }) => {
                const wins = team.form.filter((f) => f === "W").length;
                const draws = team.form.filter((f) => f === "D").length;
                const losses = team.form.filter((f) => f === "L").length;
                const pts = wins * 3 + draws;
                return (
                  <View key={team.id} style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                    <View style={styles.formCardHeader}>
                      <TeamLogo crest={team.crest} tla={team.tla} size={40} />
                      <View style={styles.formTeamInfo}>
                        <Text style={[styles.formTeamName, { color: colors.foreground }]}>{team.shortName}</Text>
                        <Text style={[styles.formTeamSide, { color: colors.mutedForeground }]}>{side}</Text>
                      </View>
                      {team.position && (
                        <View style={[styles.formPos, { backgroundColor: colors.surface }]}>
                          <Text style={[styles.formPosNum, { color: colors.foreground }]}>#{team.position}</Text>
                          <Text style={[styles.formPosLabel, { color: colors.mutedForeground }]}>{team.points}оч</Text>
                        </View>
                      )}
                    </View>
                    <Text style={[styles.formSubtitle, { color: colors.mutedForeground }]}>Последние 5 матчей</Text>
                    <FormBadges form={team.form} size="md" />
                    <View style={styles.formStats}>
                      <View style={[styles.formStat, { backgroundColor: colors.win + "15" }]}>
                        <Text style={[styles.formStatNum, { color: colors.win }]}>П {wins}</Text>
                      </View>
                      <View style={[styles.formStat, { backgroundColor: colors.draw + "15" }]}>
                        <Text style={[styles.formStatNum, { color: colors.draw }]}>Н {draws}</Text>
                      </View>
                      <View style={[styles.formStat, { backgroundColor: colors.loss + "15" }]}>
                        <Text style={[styles.formStatNum, { color: colors.loss }]}>П {losses}</Text>
                      </View>
                      <View style={[styles.formStat, { backgroundColor: colors.surface }]}>
                        <Text style={[styles.formStatNum, { color: colors.foreground }]}>{pts} оч</Text>
                      </View>
                    </View>
                    {team.goalsFor != null && (
                      <View style={styles.goalsRow}>
                        <Text style={[styles.goalsText, { color: colors.mutedForeground }]}>
                          Забито: <Text style={{ color: colors.win }}>{team.goalsFor}</Text>
                          {"  "}Пропущено: <Text style={{ color: colors.loss }}>{team.goalsAgainst}</Text>
                        </Text>
                      </View>
                    )}
                  </View>
                );
              })}
            </View>
          )}

          {tab === "betting" && (
            <View style={styles.section}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Прогнозы ИИ</Text>
              {match.prediction.tips.map((tip, i) => {
                const tracked = isTracked(match.id, tip.label);
                return (
                  <View key={i} style={[styles.tipCard, {
                    backgroundColor: tip.value > 0.10 ? colors.primary + "10" : colors.card,
                    borderColor: tip.value > 0.10 ? colors.primary + "50" : colors.border,
                  }]}>
                    <View style={styles.tipCardLeft}>
                      {tip.value > 0.10 && (
                        <View style={[styles.valueTag, { backgroundColor: colors.primary + "22" }]}>
                          <Text style={[styles.valueTagText, { color: colors.primary }]}>
                            VALUE +{(tip.value * 100).toFixed(0)}%
                          </Text>
                        </View>
                      )}
                      <Text style={[styles.tipCardLabel, { color: colors.foreground }]}>{tip.label}</Text>
                      <View style={styles.tipCardConf}>
                        <Text style={[styles.tipCardConfText, { color: colors.mutedForeground }]}>
                          Уверенность: {tip.confidence}%
                        </Text>
                      </View>
                    </View>
                    <View style={styles.tipCardRight}>
                      <Text style={[styles.tipCardOdds, { color: tip.value > 0.10 ? colors.primary : colors.foreground }]}>
                        {tip.odds.toFixed(2)}
                      </Text>
                      <View style={styles.tipCardActions}>
                        <TouchableOpacity
                          onPress={() => {
                            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                            if (tracked) removeTracked(match.id, tip.label);
                            else trackOdds({ matchId: match.id, matchTitle: `${match.homeTeam.shortName}–${match.awayTeam.shortName}`, betLabel: tip.label, initialOdds: tip.odds, currentOdds: tip.odds });
                          }}
                          style={[styles.tipActionBtn, { backgroundColor: tracked ? colors.primary + "22" : colors.surface, borderColor: tracked ? colors.primary : colors.border }]}
                        >
                          <Feather name={tracked ? "bell-off" : "bell"} size={12} color={tracked ? colors.primary : colors.mutedForeground} />
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => handleAddTip(tip.label, tip.odds)}
                          style={[styles.tipActionBtn, { backgroundColor: colors.primary, borderColor: colors.primary }]}
                        >
                          <Feather name="plus" size={12} color={colors.primaryForeground} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                );
              })}

              <Text style={[styles.sectionTitle, { color: colors.foreground, marginTop: 12 }]}>Коэффициенты</Text>
              {match.odds.map((b) => (
                <View key={b.bookmaker} style={[styles.bookRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <View style={[styles.bookIcon, { backgroundColor: colors.surface }]}>
                    <Text style={[styles.bookIconText, { color: colors.mutedForeground }]}>{b.bookmaker.slice(0, 3)}</Text>
                  </View>
                  <Text style={[styles.bookName, { color: colors.foreground }]}>{b.bookmaker}</Text>
                  {(["home", "draw", "away"] as const).map((k) => {
                    const labels = { home: "П1", draw: "X", away: "П2" };
                    const val = b[k];
                    if (!val) return null;
                    return (
                      <View key={k} style={[styles.bookOddsCell, { backgroundColor: colors.surface }]}>
                        <Text style={[styles.bookOddsLabel, { color: colors.mutedForeground }]}>{labels[k]}</Text>
                        <Text style={[styles.bookOddsVal, { color: colors.foreground }]}>{val.toFixed(2)}</Text>
                      </View>
                    );
                  })}
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      <Modal visible={showAddModal} transparent animationType="slide" onRequestClose={() => setShowAddModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.modalHandle} />
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Добавить в историю</Text>
            <Text style={[styles.modalMatch, { color: colors.mutedForeground }]}>
              {match.homeTeam.shortName} — {match.awayTeam.shortName}
            </Text>
            {selectedTip && (
              <View style={[styles.modalTip, { backgroundColor: colors.surface }]}>
                <Text style={[styles.modalTipLabel, { color: colors.foreground }]}>{selectedTip.label}</Text>
                <Text style={[styles.modalTipOdds, { color: colors.primary }]}>{selectedTip.odds.toFixed(2)}</Text>
              </View>
            )}
            <Text style={[styles.stakeLabel, { color: colors.mutedForeground }]}>Сумма ставки (₽)</Text>
            <TextInput
              style={[styles.stakeInput, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]}
              value={stake}
              onChangeText={setStake}
              keyboardType="numeric"
              placeholder="100"
              placeholderTextColor={colors.mutedForeground}
            />
            {selectedTip && stake && !isNaN(parseFloat(stake)) && (
              <Text style={[styles.potentialWin, { color: colors.mutedForeground }]}>
                Потенциальный выигрыш:{" "}
                <Text style={{ color: colors.win }}>
                  {(parseFloat(stake) * selectedTip.odds).toFixed(0)}₽
                </Text>
              </Text>
            )}
            <View style={styles.modalActions}>
              <TouchableOpacity
                onPress={() => setShowAddModal(false)}
                style={[styles.modalCancelBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
              >
                <Text style={[styles.modalCancelText, { color: colors.mutedForeground }]}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleConfirmAdd}
                style={[styles.modalConfirmBtn, { backgroundColor: colors.primary }]}
              >
                <Feather name="plus" size={14} color={colors.primaryForeground} />
                <Text style={[styles.modalConfirmText, { color: colors.primaryForeground }]}>Добавить</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  loadingText: { fontSize: 16, fontFamily: "Inter_400Regular" },
  backBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  backBtnText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  topGrad: { position: "absolute", top: 0, left: 0, right: 0 },
  navBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 8 },
  navBtn: { width: 38, height: 38, borderRadius: 12, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  navLeague: { flexDirection: "row", alignItems: "center", gap: 5 },
  navFlag: { fontSize: 16 },
  navLeagueText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  hero: { paddingHorizontal: 16, paddingBottom: 8 },
  teamsRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  teamBlock: { flex: 1, alignItems: "flex-start", gap: 6 },
  teamBlockRight: { alignItems: "flex-end" },
  teamName: { fontSize: 14, fontFamily: "Inter_700Bold", lineHeight: 18, maxWidth: 110 },
  teamPos: { fontSize: 11, fontFamily: "Inter_400Regular" },
  centreBadge: { alignItems: "center", paddingHorizontal: 8 },
  scoreCard: { borderRadius: 16, borderWidth: 1, paddingHorizontal: 16, paddingVertical: 12, alignItems: "center", gap: 4, minWidth: 90 },
  scoreLabel: { fontSize: 10, fontFamily: "Inter_500Medium" },
  scoreLarge: { fontSize: 30, fontFamily: "Inter_700Bold" },
  livePill: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100, borderWidth: 1 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  liveTxt: { fontSize: 10, fontFamily: "Inter_700Bold" },
  tabBar: { flexDirection: "row", marginHorizontal: 16, borderRadius: 14, borderWidth: 1, marginBottom: 4, overflow: "hidden" },
  tabBtn: { flex: 1, alignItems: "center", paddingVertical: 12, borderBottomWidth: 2 },
  tabTxt: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  body: { paddingHorizontal: 16 },
  section: { gap: 12, paddingTop: 12 },
  riskRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  aiCard: { borderRadius: 16, borderWidth: 1, padding: 14, gap: 10 },
  aiHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  aiIcon: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  aiTitle: { fontSize: 15, fontFamily: "Inter_700Bold" },
  aiInsight: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 20 },
  reasonList: { gap: 7 },
  reasonItem: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  reasonDot: { width: 6, height: 6, borderRadius: 3, marginTop: 5 },
  reasonText: { flex: 1, fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 18 },
  tagsRow: { flexDirection: "row", gap: 8 },
  tag: { flex: 1, borderRadius: 12, borderWidth: 1, padding: 10, gap: 4, alignItems: "center" },
  tagLabel: { fontSize: 10, fontFamily: "Inter_400Regular" },
  tagVal: { fontSize: 14, fontFamily: "Inter_700Bold" },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_700Bold", marginBottom: 4 },
  h2hStats: { flexDirection: "row", gap: 8, marginBottom: 4 },
  h2hStatBox: { flex: 1, borderRadius: 12, borderWidth: 1, padding: 12, alignItems: "center", gap: 4 },
  h2hStatNum: { fontSize: 28, fontFamily: "Inter_700Bold" },
  h2hStatLabel: { fontSize: 11, fontFamily: "Inter_500Medium" },
  h2hRow: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, borderWidth: 1, padding: 10, overflow: "hidden" },
  h2hStripe: { width: 3, height: "100%" as any, borderRadius: 2, position: "absolute", left: 0, top: 0, bottom: 0 },
  h2hDate: { fontSize: 11, fontFamily: "Inter_400Regular", width: 55, marginLeft: 6 },
  h2hTeams: { flex: 1, flexDirection: "row", alignItems: "center", gap: 6 },
  h2hTeam: { flex: 1, fontSize: 12, fontFamily: "Inter_500Medium" },
  h2hScore: { fontSize: 16, fontFamily: "Inter_700Bold", paddingHorizontal: 8 },
  h2hSeason: { fontSize: 10, fontFamily: "Inter_400Regular" },
  formCard: { borderRadius: 16, borderWidth: 1, padding: 14, gap: 10 },
  formCardHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  formTeamInfo: { flex: 1 },
  formTeamName: { fontSize: 15, fontFamily: "Inter_700Bold" },
  formTeamSide: { fontSize: 12, fontFamily: "Inter_400Regular" },
  formPos: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, alignItems: "center" },
  formPosNum: { fontSize: 14, fontFamily: "Inter_700Bold" },
  formPosLabel: { fontSize: 10, fontFamily: "Inter_400Regular" },
  formSubtitle: { fontSize: 11, fontFamily: "Inter_500Medium" },
  formStats: { flexDirection: "row", gap: 6 },
  formStat: { flex: 1, borderRadius: 8, paddingVertical: 6, alignItems: "center" },
  formStatNum: { fontSize: 13, fontFamily: "Inter_700Bold" },
  goalsRow: {},
  goalsText: { fontSize: 13, fontFamily: "Inter_400Regular" },
  tipCard: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 14, borderWidth: 1, padding: 14 },
  tipCardLeft: { flex: 1, gap: 5, marginRight: 10 },
  valueTag: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 100 },
  valueTagText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  tipCardLabel: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  tipCardConf: {},
  tipCardConfText: { fontSize: 11, fontFamily: "Inter_400Regular" },
  tipCardRight: { alignItems: "center", gap: 8 },
  tipCardOdds: { fontSize: 26, fontFamily: "Inter_700Bold" },
  tipCardActions: { flexDirection: "row", gap: 6 },
  tipActionBtn: { width: 32, height: 32, borderRadius: 10, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  bookRow: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, borderWidth: 1, padding: 10 },
  bookIcon: { width: 36, height: 36, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  bookIconText: { fontSize: 9, fontFamily: "Inter_700Bold" },
  bookName: { flex: 1, fontSize: 13, fontFamily: "Inter_600SemiBold" },
  bookOddsCell: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5, alignItems: "center", minWidth: 46 },
  bookOddsLabel: { fontSize: 9, fontFamily: "Inter_500Medium" },
  bookOddsVal: { fontSize: 15, fontFamily: "Inter_700Bold" },
  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.7)" },
  modalSheet: { borderRadius: 24, borderWidth: 1, padding: 24, margin: 12, gap: 12 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: "#555", alignSelf: "center", marginBottom: 4 },
  modalTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  modalMatch: { fontSize: 13, fontFamily: "Inter_400Regular" },
  modalTip: { borderRadius: 12, padding: 12, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modalTipLabel: { fontSize: 13, fontFamily: "Inter_600SemiBold", flex: 1 },
  modalTipOdds: { fontSize: 22, fontFamily: "Inter_700Bold" },
  stakeLabel: { fontSize: 12, fontFamily: "Inter_500Medium" },
  stakeInput: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, fontSize: 20, fontFamily: "Inter_700Bold" },
  potentialWin: { fontSize: 13, fontFamily: "Inter_400Regular" },
  modalActions: { flexDirection: "row", gap: 10, marginTop: 4 },
  modalCancelBtn: { flex: 1, borderRadius: 12, borderWidth: 1, paddingVertical: 14, alignItems: "center" },
  modalCancelText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  modalConfirmBtn: { flex: 2, borderRadius: 12, paddingVertical: 14, alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 6 },
  modalConfirmText: { fontSize: 14, fontFamily: "Inter_700Bold" },
});
